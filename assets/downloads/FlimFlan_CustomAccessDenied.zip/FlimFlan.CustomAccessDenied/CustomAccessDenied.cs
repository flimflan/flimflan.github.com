using System;
using System.Web;
using System.Web.Configuration;

namespace FlimFlan
{
    public class CustomAccessDenied : IHttpModule
    {
        static bool enabled;
        static string redirectPage;
        static bool remoteOnly;
        const int AccessDeniedStatusCode = 401;

        static CustomAccessDenied()
        {
            CustomErrorsSection section = WebConfigurationManager.GetWebApplicationSection(@"system.web/customErrors") as CustomErrorsSection;
            if (section == null || section.Mode == CustomErrorsMode.Off)
            {
                enabled = false;
                return;
            }

            remoteOnly = (section.Mode == CustomErrorsMode.RemoteOnly);

            CustomError definedError = section.Errors.Get(AccessDeniedStatusCode.ToString());
            redirectPage = (definedError != null) ? definedError.Redirect : section.DefaultRedirect;
            enabled = true;
        }

        public void Init(HttpApplication application)
        {
            if (!enabled) return;

            application.EndRequest += RedirectWhenAccessDenied;
        }

        void RedirectWhenAccessDenied(object sender, EventArgs e)
        {
            HttpApplication application = (HttpApplication)sender;
            if (remoteOnly && application.Request.IsLocal) return;
            if (application.Response.StatusCode != AccessDeniedStatusCode || !application.Request.IsAuthenticated) return;

            application.Response.ClearContent();
            application.Server.Execute(redirectPage);
        }

        public void Dispose() { }
    }
}

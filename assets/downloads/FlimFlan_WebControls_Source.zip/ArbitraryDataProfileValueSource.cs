using System;
using System.Collections.Generic;
using System.Text;

namespace FlimFlan.WebControls
{
    class ArbitraryDataProfileValueSource :IProfileValueSource
    {
        Random r = new Random();

        private bool isAnonymous;
        public ArbitraryDataProfileValueSource(bool isAnonymous)
        {
            this.isAnonymous = isAnonymous;
        }

        #region IProfileValueSource Members

        public object GetPropertyValue(string propertyName)
        {
            return r.Next();
        }

        public void SetPropertyValue(string propertyName, object propertyValue)
        {
            // don't do anything
        }

        public void Save()
        {
            // don't do anything
        }

        public bool UserIsAuthenticated
        {
            get
            {
                return !isAnonymous;
            }
        }

        #endregion
    }
}

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FlimFlan.WebControls
{
    /// <summary>
    /// Creates the appropriate HTML control to render a SettingsProperty
    /// </summary>
    public class ControlBuilder
    {

        /// <summary>
        /// Creates an editable presentation for a profile property
        /// </summary>
        /// <param name="property">The profile property to display</param>
        /// <returns></returns>
        public WebControl CreateEditControl(System.Configuration.SettingsProperty property)
        {
            //TODO: return a panel control when a validator is needed?
            WebControl c;
            if (property.PropertyType == typeof(bool))
            {
                c = new CheckBox();
            }
            else
            {
                c = new TextBox();
            }
            c.ID = property.Name;
            return c;
        }

        /// <summary>
        /// Creates a read-only presentation for a profile property
        /// </summary>
        /// <param name="property">The profile property to display</param>
        /// <returns></returns>
        public WebControl CreateDisplayControl(System.Configuration.SettingsProperty property)
        {
            WebControl c;
            c = new Label();
            c.ID = property.Name;
            return c;
        }

        private const string DEFAULT_VALIDATION_GROUP = "ProfileView";
        private const string DEFAULT_VALIDATION_ERROR_MESSAGE = "*";

        /// <summary>
        /// Creates a type checking validator control for a profile property
        /// </summary>
        /// <param name="property">The profile property to validate</param>
        /// <returns></returns>
        public BaseValidator CreateValidationControl(System.Configuration.SettingsProperty property)
        {
            CompareValidator validator = null;
            ValidationDataType validationType = GetValidationType(property.PropertyType);
            if (validationType != ValidationDataType.String)
            {
                validator = new CompareValidator();
                validator.ID = "val_" + property.Name;
                validator.Operator = ValidationCompareOperator.DataTypeCheck;
                validator.Type = validationType;
                validator.ValidationGroup = DEFAULT_VALIDATION_GROUP;
                validator.ErrorMessage = DEFAULT_VALIDATION_ERROR_MESSAGE;
                validator.Display = ValidatorDisplay.Dynamic;
            }
            return validator;
        }

        internal ValidationDataType GetValidationType(System.Type type)
        {
            switch (type.FullName)
            {
                case "System.Byte":
                    return ValidationDataType.Integer;
                case "System.DateTime":
                    return ValidationDataType.Date;
                case "System.Decimal":
                case "System.Double":
                    return ValidationDataType.Double;
                case "System.Int16":
                case "System.Int32":
                case "System.Int64":
                    return ValidationDataType.Integer;
                case "System.Single":
                    return ValidationDataType.Double;
                case "System.SByte":
                    return ValidationDataType.Integer;
                case "System.UInt16":
                case "System.UInt32":
                case "System.UInt64":
                    return ValidationDataType.Integer;
                default:
                    return ValidationDataType.String;
            }
        }
    }
}

// FlimFlan.WebControls.ProfileView
// Created by Joshua Flanagan, 2004
// Use at your own risk.  Please send changes or requests to the website.
// http://flimflan.com/blog

#region Using directives

using System;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Web;
using System.Collections.Generic;
using System.IO;
using System.Configuration;
using System.Web.UI.Design.WebControls;
using System.Web.UI.Design;
using System.Web.Configuration;
using System.ComponentModel.Design;
using System.ComponentModel;
#endregion

namespace FlimFlan.WebControls.Design
{
    /// <remarks>
    /// Provides design time support for the <see cref="ProfileView"/> control.
    /// </remarks>
    class ProfileViewDesigner : CompositeControlDesigner
    {
        SettingsProperty[] profileProperties;
        bool IsConfigurationRead;

        public ProfileViewDesigner()
        {
            IsConfigurationRead = false;
        }

        public override bool AllowResize
        {
            get
            {
                return false;
            }
        }

        private bool _IsAnonymousView = false;
        protected bool IsAnonymousView
        {
            get { return _IsAnonymousView; }
            set
            {
                _IsAnonymousView = value;
                ProfileView profileView = (ProfileView)this.ViewControl;
                profileView.SetProfileValueSource(new ArbitraryDataProfileValueSource(_IsAnonymousView));
                ((ICompositeControlDesignerAccessor)profileView).RecreateChildControls();

                profileView.ChangeDesignTimeView = true;
                this.RaiseComponentChanged(null, null, true);
            }
            
        }


        public override string GetDesignTimeHtml()
        {
            System.Diagnostics.Debug.WriteLine("Calling GetDesignTimeHtml");
            ProfileView profileView = (ProfileView)this.ViewControl;
            if (!IsConfigurationRead)
            {
                profileProperties = getSettingsPropertiesFromConfiguration();
                if (profileProperties.Length  > 0)
                {
                    IsConfigurationRead = true;
                }
                else
                {
                    profileProperties = getArbitrarySettingsProperties();
                }
            }
            
            profileView.SetConfiguredProperties(profileProperties);
            profileView.SetProfileValueSource(new ArbitraryDataProfileValueSource(_IsAnonymousView));

            return base.GetDesignTimeHtml();
        }

        #region Create list of profile properties

        private SettingsProperty[] getSettingsPropertiesFromConfiguration()
        {
            IWebApplication webApp = (IWebApplication)base.Component.Site.GetService(typeof(IWebApplication));
            if (webApp == null) return new SettingsProperty[] { };
            System.Configuration.Configuration config = webApp.OpenWebConfiguration(true);

            return ProfileView.GetPropertiesFromConfiguration(config);
        }


        private SettingsProperty[] getArbitrarySettingsProperties()
        {
            List<SettingsProperty> properties = new List<SettingsProperty>();
            SettingsProperty property = new SettingsProperty("FirstName");
            property.PropertyType = typeof(String);
            properties.Add(property);
            property = new SettingsProperty("LastName");
            property.PropertyType = typeof(String);
            properties.Add(property);
            property = new SettingsProperty("Age");
            property.PropertyType = typeof(Int32);
            properties.Add(property);

            property = new SettingsProperty("Address.Street");
            property.PropertyType = typeof(String);
            properties.Add(property);
            property = new SettingsProperty("Address.City");
            property.PropertyType = typeof(String);
            properties.Add(property);
            property = new SettingsProperty("Address.State");
            property.PropertyType = typeof(String);
            properties.Add(property);

            return properties.ToArray();
        }

        #endregion

        public override DesignerActionListCollection ActionLists
        {
            get
            {
                DesignerActionListCollection actionLists = new DesignerActionListCollection();
                actionLists.AddRange(base.ActionLists);
                actionLists.Add(new ProfileViewActionList(this));
                return actionLists;
            }
        }

        private class ProfileViewActionList : DesignerActionList
        {
            ProfileViewDesigner parent;
            DesignerActionItemCollection items;

            public ProfileViewActionList(ProfileViewDesigner parent) : base(parent.Component)
            {
                this.parent = parent;
            }
            //TODO: find out how to persist designer settings
            public bool IsAnonymousView
            {
                get { return parent.IsAnonymousView; }
                set { parent.IsAnonymousView = value; }
            }

            public override DesignerActionItemCollection GetSortedActionItems()
            {
                if (items == null)
                {
                    items = new DesignerActionItemCollection();
                    items.Add(new DesignerActionTextItem("Preview Settings:", "Preview"));
                    items.Add(new DesignerActionPropertyItem("IsAnonymousView", "Preview as anonymous user", "Preview", "When enabled, you will only see the profile properties that are available to anonymous users."));
                }
                return items;
            }
        }
    }
}

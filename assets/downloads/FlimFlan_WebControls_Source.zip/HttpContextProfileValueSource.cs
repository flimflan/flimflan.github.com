using System;
using System.Collections.Generic;
using System.Text;

namespace FlimFlan.WebControls
{
    class HttpContextProfileValueSource :IProfileValueSource
    {
        System.Web.HttpContext context;

        public HttpContextProfileValueSource(System.Web.HttpContext context)
        {
            this.context = context;
        }

        #region IProfileValueSource Members

        public object GetPropertyValue(string propertyName)
        {
            return context.Profile.GetPropertyValue(propertyName);
        }

        public void SetPropertyValue(string propertyName, object propertyValue)
        {
            context.Profile.SetPropertyValue(propertyName, propertyValue);
        }

        public void Save()
        {
            // we want to force a save, even if AutomaticSaveEnabled is false
            context.Profile.Save();
        }

        public bool UserIsAuthenticated
        {
            get
            {
                return context.User.Identity.IsAuthenticated;
            }
        }

        #endregion
    }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace FlimFlan.WebControls
{
    interface IProfileValueSource
    {
        object GetPropertyValue(string propertyName);

        void SetPropertyValue(string propertyName, object propertyValue);

        bool UserIsAuthenticated { get; }

        void Save();
    }
}

// FlimFlan.WebControls.ProfileView
// Created by Joshua Flanagan, 2004
// Use at your own risk.  Please send changes or requests to the website.
// http://flimflan.com/blog

#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Profile;
using System.Web.Configuration;
#endregion

[assembly: TagPrefix("FlimFlan.WebControls", "flim")]

namespace FlimFlan.WebControls
{
    /// <remarks>
    /// Creates an editable user-interface for managing a user's ASP.NET Profile properties
    /// </remarks>
    [ToolboxData("<{0}:ProfileView runat=\"server\" />")]
    [Designer(typeof(Design.ProfileViewDesigner))]
    public class ProfileView: CompositeControl
    {
        IButtonControl saveButton;
        IButtonControl resetButton;

        List<String> groupNames;
        Dictionary<String, List<String>> controlsByGroup;

        Dictionary<String, WebControl> inputControls;
        Dictionary<String, WebControl> validatorControls;


        SettingsProperty[] configuredProperties;
        IProfileValueSource valueSource;

        public ProfileView()
        {
            groupNames = new List<String>();
            controlsByGroup = new Dictionary<String, List<String>>();

            inputControls = new Dictionary<String, WebControl>(ProfileBase.Properties.Count);
            validatorControls = new Dictionary<String, WebControl>(ProfileBase.Properties.Count);

            this.configuredProperties = getConfiguredProperties();
            this.valueSource = new HttpContextProfileValueSource(HttpContext.Current);
        }

        private SettingsProperty[] getConfiguredProperties()
        {
            //TODO: cache configuration settings so they are not read on every page load for every user
            string appPath = null;
            HttpContext context = HttpContext.Current;
            if (context != null)
            {
                appPath = HttpContext.Current.Request.ApplicationPath;
            }
            return GetPropertiesFromConfiguration(WebConfigurationManager.OpenWebConfiguration(appPath));
        }

        internal void SetConfiguredProperties(SettingsProperty[] configuredProperties)
        {
            this.configuredProperties = configuredProperties;
        }
        internal void SetProfileValueSource(IProfileValueSource valueSource)
        {
            this.valueSource = valueSource;
        }

        #region Properties - Appearance

        private string _DefaultGroupText = "Profile";

        /// <summary>
        /// The label for profile settings that do not belong to a group.
        /// </summary>
        /// <value></value>
        [Category("Appearance")]
        [DefaultValue("Profile")]
        [Description("The label for profile settings that do not belong to a group.")]
        public string DefaultGroupText
        {
            get { return _DefaultGroupText; }
            set { _DefaultGroupText = value.Trim(); }
        }

        private bool _FriendlyLabels = true;

        /// <summary>
        /// Separates camel-cased multiple word property names.  Ex: 'FontName' displays as 'Font Name'.
        /// </summary>
        /// <value></value>
        [Category("Appearance")]
        [DefaultValue(true)]
        [Description("Separates PascalCased multiple word property names.  Ex: 'FontName' displays as 'Font Name'.")]
        public bool FriendlyLabels
        {
            get { return _FriendlyLabels; }
            set { _FriendlyLabels = value; }
        }


        private string _ResetButtonText = "Reset";

        /// <summary>
        /// The label on the button that resets profile settings.
        /// </summary>
        /// <value></value>
        [Category("Appearance")]
        [DefaultValue("Reset")]
        [Description("The label on the button that resets profile settings.")]
        public string ResetButtonText
        {
            get { return _ResetButtonText; }
            set { _ResetButtonText = value; }
        }

        private string _SaveButtonText = "Save";

        /// <summary>
        /// The label on the button that saves profile settings.
        /// </summary>
        /// <value></value>
        [Category("Appearance")]
        [DefaultValue("Save")]
        [Description("The label on the button that saves profile settings.")]
        public string SaveButtonText
        {
            get { return _SaveButtonText; }
            set { _SaveButtonText = value; }
        }
        
        ButtonType _ResetButtonType = ButtonType.Link;
        ButtonType _SaveButtonType = ButtonType.Button;

        /// <summary>
        /// The type of button used for resetting the profile data.
        /// </summary>
        /// <value></value>
        [Category("Appearance")]
        [DefaultValue(ButtonType.Link)]
        [Description("The type of button used for resetting the profile data.")]
        public ButtonType ResetButtonType
        {
            get { return _ResetButtonType; }
            set { _ResetButtonType = value; }
        }

        /// <summary>
        /// The type of button used for saving the profile data.
        /// </summary>
        /// <value></value>
        [Category("Appearance")]
        [DefaultValue(ButtonType.Button)]
        [Description("The type of button used for saving the profile data.")]
        public ButtonType SaveButtonType
        {
            get { return _SaveButtonType; }
            set { _SaveButtonType = value; }
        }

        private string _ResetButtonImageUrl;

        /// <summary>
        /// The URL of the image to be shown as a reset button.
        /// </summary>
        /// <value></value>
        [Category("Appearance")]
        [Description("The URL of the image to be shown as a reset button.")]
        [Editor(typeof(System.Web.UI.Design.ImageUrlEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string ResetButtonImageUrl
        {
            get { return _ResetButtonImageUrl; }
            set { _ResetButtonImageUrl = value; }
        }

        private string _SaveButtonImageUrl;

        /// <summary>
        /// The URL of the image to be shown as a save button.
        /// </summary>
        /// <value></value>
        [Category("Appearance")]
        [Description("The URL of the image to be shown as a save button.")]
        [Editor(typeof(System.Web.UI.Design.ImageUrlEditor), typeof(System.Drawing.Design.UITypeEditor))]
        public string SaveButtonImageUrl
        {
            get { return _SaveButtonImageUrl; }
            set { _SaveButtonImageUrl = value; }
        }

        #endregion

        #region Properties - Behavior
        private bool _ReadOnly = false;

        /// <summary>
        /// Determines whether a user is able to edit profile values
        /// </summary>
        /// <value></value>
        [Category("Behavior")]
        [DefaultValue(false)]
        [Description("Determines whether a user is able to edit profile values.")]
        public bool ReadOnly
        {
            get { return _ReadOnly; }
            set { _ReadOnly = value; }
        }

        private string _UserName = null;
        
        /// <summary>
        /// Specifies the user whose profile is used to populate the control
        /// </summary>
        [Category("Behavior")]
        [Description("Specifies the user whose profile is used to populate the control")]
        public string UserName
        {
            get { return _UserName; }
            set { _UserName = value; }
        }

        #endregion

        #region Properties - Style
        Style _PropertyLabelStyle;
        Style _PropertyTextBoxStyle;
        Style _GroupLabelStyle;

        /// <summary>
        /// The style to be applied to text box entry fields.
        /// </summary>
        /// <value></value>
        [Category("Style")]
        [Description("The style to be applied to text box entry fields.")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [NotifyParentProperty(true)]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        public virtual Style PropertyTextBoxStyle
        {
            get
            {
                if (_PropertyTextBoxStyle == null)
                {
                    _PropertyTextBoxStyle = new Style();
                    if (IsTrackingViewState)
                        ((IStateManager)_PropertyTextBoxStyle).TrackViewState();
                }
                return _PropertyTextBoxStyle;
            }
        }

        /// <summary>
        /// The style to be applied to each profile property name.
        /// </summary>
        /// <value></value>
        [Category("Style")]
        [Description("The style to be applied to each profile property name.")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [NotifyParentProperty(true)]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        public virtual Style PropertyLabelStyle
        {
            get
            {
                if (_PropertyLabelStyle == null)
                {
                    _PropertyLabelStyle = new Style();
                    if (IsTrackingViewState)
                        ((IStateManager)_PropertyLabelStyle).TrackViewState();
                }
                return _PropertyLabelStyle;
            }
        }
        /// <summary>
        /// The style to be applied to each profile property name.
        /// </summary>
        /// <value></value>
        [Category("Style")]
        [Description("The style to be applied to each profile property group heading.")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [NotifyParentProperty(true)]
        [PersistenceMode(PersistenceMode.InnerProperty)]
        public virtual Style GroupLabelStyle
        {
            get
            {
                if (_GroupLabelStyle == null)
                {
                    _GroupLabelStyle = new Style();
                    if (IsTrackingViewState)
                        ((IStateManager)_GroupLabelStyle).TrackViewState();
                }
                return _GroupLabelStyle;
            }
        }

 #endregion

        #region User Interface Events
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (!String.IsNullOrEmpty(_UserName))
            {
                this.valueSource = new SpecificUserProfileValueSource(_UserName);
            }
            if (!Page.IsPostBack)
            {
                ResetForm();
            }
        }
        void saveButton_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                SaveForm();
                OnSave();
            }
        }
        void resetButton_Click(object sender, EventArgs e)
        {
            ResetForm();
            OnReset();
        }
        #endregion

        #region Raised Events

        [Category("Behavior")]
        [Description("Fires when the user clicks the Reset button.")]
        public event EventHandler Reset;

        [Category("Behavior")]
        [Description("Fires when the user clicks the Save button and all property values are valid.")]
        public event EventHandler Save;

        protected virtual void OnReset()
        {
            if (Reset != null)
            {
                Reset(this, EventArgs.Empty);
            }
        }
        protected virtual void OnSave()
        {
            if (Save != null)
            {
                Save(this, EventArgs.Empty);
            }
        }

        #endregion

        #region Button Actions
        /// <summary>
        /// Loads the current value of each profile property into its respective control
        /// </summary>
        private void ResetForm()
        {
            EnsureChildControls();
            foreach (WebControl control in inputControls.Values)
            {
                ShowProfileProperty(control);
            }
        }
        /// <summary>
        /// Saves the contents of each control into its respective profile property
        /// </summary>
        private void SaveForm()
        {
            EnsureChildControls();
            foreach (WebControl control in inputControls.Values)
            {
                SetProfileProperty(control);
            }
            valueSource.Save();
        }
        #endregion

        #region Build control tree

        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [DesignOnly(true)]
        internal bool ChangeDesignTimeView
        {
            get { return false; }
            set { }
        }

        protected override void CreateChildControls()
        {
            groupNames.Clear();
            controlsByGroup.Clear();
            inputControls.Clear();
            validatorControls.Clear();

            ControlBuilder builder = new ControlBuilder();
            // add all of the input controls
            foreach (SettingsProperty property in configuredProperties)
            {
                // Filter out properties that are not available to anonymous users
                if (IsPropertyAvailable(property))
                {
                    //build a list of available groups
                    string group = GetGroupName(property.Name);
                    if (!controlsByGroup.ContainsKey(group))
                    {
                        groupNames.Add(group);
                        controlsByGroup.Add(group, new List<String>());
                    }

                    WebControl displayControl;
                    if (_ReadOnly || property.IsReadOnly)
                    {
                        // create a read-only presentation for the property
                        displayControl = builder.CreateDisplayControl(property);
                    }
                    else
                    {
                        // create an editable presentation for the property
                        displayControl = builder.CreateEditControl(property);
                        //create a validator, if possible
                        BaseValidator validator = builder.CreateValidationControl(property);
                        if (validator != null)
                        {
                            validator.ControlToValidate = displayControl.ID;
                            this.Controls.Add(validator);
                            validatorControls.Add(property.Name, validator);
                        }
                    }
                    this.Controls.Add(displayControl);
                    controlsByGroup[group].Add(property.Name);
                    inputControls.Add(property.Name, displayControl);
                }
            }

            // Only show the Reset/Save buttons if the profile is editable
            if (!_ReadOnly)
            {
                switch (_SaveButtonType)
                {
                    case ButtonType.Button:
                        saveButton = new Button();
                        break;
                    case ButtonType.Image:
                        ImageButton sImageButton = new ImageButton();
                        sImageButton.ImageUrl = _SaveButtonImageUrl;
                        sImageButton.AlternateText = _SaveButtonText;
                        saveButton = sImageButton;
                        break;
                    case ButtonType.Link:
                        saveButton = new LinkButton();
                        break;
                    default:
                        throw new InvalidEnumArgumentException();
                }
                saveButton.Text = _SaveButtonText;
                saveButton.Click += new EventHandler(saveButton_Click);
                saveButton.ValidationGroup = "ProfileView";
                saveButton.CausesValidation = true;
                switch (_ResetButtonType)
                {
                    case ButtonType.Button:
                        resetButton = new Button();
                        break;
                    case ButtonType.Image:
                        ImageButton rImageButton = new ImageButton();
                        rImageButton.ImageUrl = _ResetButtonImageUrl;
                        rImageButton.AlternateText = _ResetButtonText;
                        resetButton = rImageButton;
                        break;
                    case ButtonType.Link:
                        resetButton = new LinkButton();
                        break;
                    default:
                        throw new InvalidEnumArgumentException();
                }
                resetButton.Text = _ResetButtonText;
                resetButton.Click += new EventHandler(resetButton_Click);
                resetButton.CausesValidation = false;

                this.Controls.Add((WebControl)resetButton);
                this.Controls.Add((WebControl)saveButton);
            }
            //TODO: add an optional errorprovider to summarize errors
        }

        #endregion

        #region Render
        protected override void Render(HtmlTextWriter writer)
        {
            //renderWithTables(writer);
            this.EnsureChildControls();
            renderWithDivs(writer);
        }

        private void renderWithDivs(HtmlTextWriter writer)
        {
            this.AddAttributesToRender(writer);

            writer.AddAttribute(HtmlTextWriterAttribute.Id, "mainHolder");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);

            foreach (string groupName in groupNames)
            {
                string groupHeading = String.IsNullOrEmpty(groupName) ? _DefaultGroupText : groupName;

                writer.AddAttribute(HtmlTextWriterAttribute.Id, "groupHolder_" + groupHeading);
                writer.RenderBeginTag(HtmlTextWriterTag.Div);

                renderGroupHeading(writer, groupHeading);

                foreach (string propertyName in controlsByGroup[groupName])
                {
                    renderProperty(writer, propertyName);
                }

                writer.RenderEndTag(); // group DIV
            }
            renderButtons(writer);
            writer.RenderEndTag(); // main DIV
        }

        private void renderButtons(HtmlTextWriter writer)
        {
            if (_ReadOnly) return;

            writer.AddAttribute(HtmlTextWriterAttribute.Id, "buttonPanel");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);

            ((WebControl)resetButton).RenderControl(writer);
            ((WebControl)saveButton).RenderControl(writer);

            writer.RenderEndTag();
        }

        private void renderProperty(HtmlTextWriter writer, string propertyName)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Id, "propHolder_" + propertyName);
            writer.RenderBeginTag(HtmlTextWriterTag.Div);

            // add label
            Label propertyCaption = new Label();
            propertyCaption.Text = createLabelText(propertyName, _FriendlyLabels);
            propertyCaption.ApplyStyle(_PropertyLabelStyle);
            propertyCaption.RenderControl(writer);

            // add input control
            WebControl inputControl = inputControls[propertyName];
            if (inputControl is TextBox)
                inputControl.ApplyStyle(_PropertyTextBoxStyle);
            inputControl.RenderControl(writer);

            // add validator control
            if (validatorControls.ContainsKey(propertyName))
            {
                validatorControls[propertyName].RenderControl(writer);
            }

            writer.RenderEndTag(); // property DIV
        }

        private void renderGroupHeading(HtmlTextWriter writer, string groupName)
        {
            Label groupHeading = new Label();
            groupHeading.ApplyStyle(_GroupLabelStyle);
            groupHeading.Text = createLabelText(groupName, _FriendlyLabels);
            groupHeading.RenderControl(writer);
        }


        private void renderWithTables(HtmlTextWriter writer)
        {
            this.AddAttributesToRender(writer);

            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "1", false);
            writer.RenderBeginTag(HtmlTextWriterTag.Table); // main table

            WebControl currentControl;
            Label propertyLabel = new Label();
            propertyLabel.ApplyStyle(_PropertyLabelStyle);

            // Create a separate sub-table for each group of profile properties
            foreach (string groupName in groupNames)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);

                writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "1", false);
                writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
                writer.RenderBeginTag(HtmlTextWriterTag.Table); // group table

                writer.RenderBeginTag(HtmlTextWriterTag.Thead);
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.AddAttribute(HtmlTextWriterAttribute.Colspan, "2");
                writer.RenderBeginTag(HtmlTextWriterTag.Th);
                if (groupName.Length == 0)
                {
                    writer.Write(_DefaultGroupText);
                }
                else
                {
                    writer.Write(groupName);
                }
                writer.RenderEndTag(); // TH
                writer.RenderEndTag(); // TR
                writer.RenderEndTag(); // THEAD

                // Create a new table row for each profile property
                foreach (string propertyName in controlsByGroup[groupName])
                {
                    currentControl = inputControls[propertyName];
                    writer.RenderBeginTag(HtmlTextWriterTag.Tr);
                    writer.AddAttribute(HtmlTextWriterAttribute.Align, "right");
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    propertyLabel.Text = createLabelText(propertyName, _FriendlyLabels);
                    propertyLabel.RenderControl(writer);
                    writer.RenderEndTag();  // Td
                    writer.RenderBeginTag(HtmlTextWriterTag.Td);
                    if (currentControl is TextBox)
                        currentControl.ApplyStyle(_PropertyTextBoxStyle);
                    currentControl.RenderControl(writer);
                    if (validatorControls.ContainsKey(propertyName))
                        validatorControls[propertyName].RenderControl(writer);
                    writer.RenderEndTag();  // Td
                    writer.RenderEndTag(); //Tr
                }

                writer.RenderEndTag(); // group cell
                writer.RenderEndTag(); // group row
                writer.RenderEndTag(); // group table
            }

            // Only show the Reset/Save buttons if the profile is editable
            if (!_ReadOnly)
            {
                // Add standard buttons
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);

                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                ((WebControl)resetButton).RenderControl(writer);
                writer.RenderEndTag();  // Td

                //TODO: add alignment properties for labels
                writer.AddAttribute(HtmlTextWriterAttribute.Align, "right");
                writer.RenderBeginTag(HtmlTextWriterTag.Td);
                ((WebControl)saveButton).RenderControl(writer);
                writer.RenderEndTag();  // Td

                writer.RenderEndTag();  // Tr
            }
            writer.RenderEndTag();  // Table
        }
#endregion

        #region Read/Write controls with property values
        void ShowProfileProperty(WebControl control)
        {
            SettingsProperty property = System.Web.Profile.ProfileBase.Properties[control.ID];
            string propertyTextValue;
            switch (property.PropertyType.FullName)
            {
                case "System.Boolean":
                    propertyTextValue = (bool) valueSource.GetPropertyValue(property.Name) ? "Yes" : "No";
                    break;
                case "System.DateTime":
                    propertyTextValue = ((DateTime)valueSource.GetPropertyValue(property.Name)).ToShortDateString();
                    break;
                case "System.String":
                    propertyTextValue = (string)valueSource.GetPropertyValue(property.Name);
                    break;
                default:
                    propertyTextValue = TypeDescriptor.GetConverter(property.PropertyType).ConvertToString(valueSource.GetPropertyValue(property.Name));
                    break;
            }

            if (_ReadOnly || property.IsReadOnly)
            {
                ((Label)control).Text = propertyTextValue;
            }
            else
            {
                if (property.PropertyType.Equals(typeof(System.Boolean)))
                {
                    ((CheckBox)control).Checked = (bool)valueSource.GetPropertyValue(property.Name);
                }
                else
                {
                    ((TextBox)control).Text = propertyTextValue;
                }
            }
        }

        void SetProfileProperty(WebControl control)
        {
            SettingsProperty property = System.Web.Profile.ProfileBase.Properties[control.ID];
            switch (property.PropertyType.FullName)
            {
                case "System.Boolean":
                    bool newBool = ((CheckBox)control).Checked;
                    valueSource.SetPropertyValue(property.Name, newBool);
                    break;
                case "System.DateTime":
                    string newDate = ((TextBox)control).Text.Trim();
                    valueSource.SetPropertyValue(property.Name, DateTime.Parse(newDate, System.Globalization.CultureInfo.CurrentUICulture));
                    break;
                case "System.Int32":
                    string newNumber = ((TextBox)control).Text.Trim();
                    int number = 0;
                    try { number = Int32.Parse(newNumber, System.Globalization.CultureInfo.CurrentUICulture); }
                    catch { number = 0;  }
                    valueSource.SetPropertyValue(property.Name, number);
                    break;
                case "System.String":
                    string newString = ((TextBox)control).Text.Trim();
                    valueSource.SetPropertyValue(property.Name, newString);
                    break;
                default:
                    string newValue = ((TextBox)control).Text.Trim();
                    try
                    {
                        object convertedValue = TypeDescriptor.GetConverter(property.PropertyType).ConvertFromString(newValue);
                        valueSource.SetPropertyValue(property.Name, convertedValue);
                    }
                    catch (Exception e) 
                    {
                        Context.Trace.Warn("SetProfileProperty", e.GetType().FullName, e);
                        // reset to original value
                        ShowProfileProperty(control);
                    }
                    break;
            }
        }
        #endregion

        #region Custom state management for styles of child controls
        // The following methods were taken directly from Nikhil Kothari's book
        protected override void LoadViewState(object savedState)
        {
            if (savedState == null)
            {
                // Always invoke LoadViewState on the base class,
                // even if there is no saved state, because the base 
                // class might have implemented some logic that needs 
                // to be executed even if there is no state to restore.
                base.LoadViewState(null);
                return;
            }

            if (savedState != null)
            {
                object[] myState = (object[])savedState;
                if (myState.Length != 4)
                {
                    throw new ArgumentException("Invalid view state");
                }

                base.LoadViewState(myState[0]);

                if (myState[1] != null)
                    ((IStateManager)PropertyLabelStyle).LoadViewState(myState[1]); 
                if (myState[2] != null)
                    ((IStateManager)PropertyTextBoxStyle).LoadViewState(myState[2]);
                if (myState[3] != null)
                    _UserName = (string) myState[3];
            }
        }

        protected override object SaveViewState()
        {
            // Customized state management to save the state of styles.
            object[] myState = new object[4];

            myState[0] = base.SaveViewState();
            myState[1] = (_PropertyLabelStyle != null) ?
                ((IStateManager)_PropertyLabelStyle).SaveViewState() : null;
            myState[2] = (_PropertyTextBoxStyle != null) ?
                ((IStateManager)_PropertyTextBoxStyle).SaveViewState() : null;
            myState[3] = _UserName;

            for (int i = 0; i < 4; i++)
            {
                if (myState[i] != null)
                {
                    return myState;
                }
            }

            // If there is no saved state, it is more performant to 
            // return null than to return an array of null values.
            return null;
        }

        protected override void TrackViewState()
        {
            // Customized state management to track the state 
            // of styles.
            base.TrackViewState();

            if (_PropertyLabelStyle != null)
                ((IStateManager)_PropertyLabelStyle).TrackViewState();
            if (_PropertyTextBoxStyle != null)
                ((IStateManager)_PropertyTextBoxStyle).TrackViewState();
        }
        #endregion Custom state management for styles of child controls

        #region Helper methods
        internal static string GetGroupName(string fullPropertyName)
        {
            string[] nameParts = fullPropertyName.Split(new char[] { '.' });
            if (nameParts.Length > 1)
            {
                return nameParts[0];
            }
            else
                return String.Empty;
        }

        private static string AttributeAllowAnonymous = "AllowAnonymous";
        /// <summary>
        /// Determines if the current user should see a property
        /// </summary>
        /// <param name="prop">The property being checked for availability</param>
        /// <returns>true if the current user can see this property</returns>
        private bool IsPropertyAvailable(SettingsProperty prop)
        {
            if (valueSource.UserIsAuthenticated)
                return true;
            else
            {
                if (prop.Attributes.ContainsKey(AttributeAllowAnonymous))
                    return (bool)prop.Attributes[AttributeAllowAnonymous];
                else
                    return false;
            }
        }
        internal static string createLabelText(string fullPropertyName, bool friendlyLabels)
        {
            string labelText;
            string[] nameParts = fullPropertyName.Split(new char[] { '.' });
            if (nameParts.Length > 1)
            {
                labelText = nameParts[nameParts.Length - 1];
            }
            else
            {
                labelText = nameParts[0];
            }
            if (friendlyLabels)
            {
                labelText = System.Text.RegularExpressions.Regex.Replace(labelText, "(?<lastLower>[a-z])(?<nextUpper>[A-Z])", "${lastLower} ${nextUpper}");
            }
            return labelText;
        }

        internal static SettingsProperty[] GetPropertiesFromConfiguration(Configuration config)
        {
            if (config == null) return new SettingsProperty[] { };
            ConfigurationSectionGroup systemWeb = config.GetSectionGroup("system.web");
            if (systemWeb == null) return new SettingsProperty[] { };
            ProfileSection profileSection = (ProfileSection)systemWeb.Sections["profile"];
            if (profileSection == null) return new SettingsProperty[] { };

            List<SettingsProperty> properties = new List<SettingsProperty>();
            foreach (ProfilePropertySettings configProperty in profileSection.PropertySettings)
            {
                SettingsProperty property = buildSettingsProperty(configProperty, null);
                if (property != null)
                {
                    properties.Add(property);
                }
            }
            foreach (ProfileGroupSettings configGroup in profileSection.PropertySettings.GroupSettings)
            {
                foreach (ProfilePropertySettings configProperty in configGroup.PropertySettings)
                {
                    SettingsProperty property = buildSettingsProperty(configProperty, configGroup.Name);
                    if (property != null)
                    {
                        properties.Add(property);
                    }
                }
            }

            return properties.ToArray();
        }

        private static SettingsProperty buildSettingsProperty(ProfilePropertySettings configProperty, string groupName)
        {
            string propertyName;
            if (String.IsNullOrEmpty(groupName))
            {
                propertyName = configProperty.Name;
            }
            else
            {
                propertyName = groupName + "." + configProperty.Name;
            }
            SettingsProperty property = new SettingsProperty(propertyName);
            // unfortunately, when a type is not specified, the default is "string" - which is not a valid type
            string type = configProperty.Type;

            if (String.Equals(type, "string", StringComparison.OrdinalIgnoreCase))
            {
                type = "System.String";
            }
            property.PropertyType = Type.GetType(type, false, true);
            // ignore this property if the type cannot be resolved
            if (property.PropertyType == null) return null;

            property.IsReadOnly = configProperty.ReadOnly;
            property.DefaultValue = configProperty.DefaultValue;
            property.Attributes["AllowAnonymous"] = configProperty.AllowAnonymous;
            return property;
        }


        #endregion
    }
}

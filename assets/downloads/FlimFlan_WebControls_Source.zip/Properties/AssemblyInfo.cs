﻿#region Using directives

using System.Reflection;
using System.Runtime.CompilerServices;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("FlimFlan.WebControls")]
[assembly: AssemblyDescription("Includes ProfileView WebControl")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("FlimFlan.com")]
[assembly: AssemblyProduct("FlimFlan.WebControls")]
[assembly: AssemblyCopyright("2004-2006 Joshua Flanagan")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.2.624.2006")]
[assembly: System.CLSCompliant(true)]
[assembly: System.Runtime.InteropServices.ComVisible(true)]
using System;
using System.Collections.Generic;
using System.Text;

namespace FlimFlan.WebControls
{
    class SpecificUserProfileValueSource : IProfileValueSource
    {
        System.Web.Profile.ProfileBase userProfile;

        public SpecificUserProfileValueSource(string userName)
        {
            userProfile = System.Web.Profile.ProfileBase.Create(userName, true);    
        }

        #region IProfileValueSource Members

        public object GetPropertyValue(string propertyName)
        {
            return userProfile.GetPropertyValue(propertyName);
        }

        public void SetPropertyValue(string propertyName, object propertyValue)
        {
            userProfile.SetPropertyValue(propertyName, propertyValue);
        }

        public void Save()
        {
            userProfile.Save();
        }

        public bool UserIsAuthenticated
        {
            get { return true; }
        }

        #endregion
    }
}

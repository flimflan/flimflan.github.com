#if TEST

using System;
using NUnit.Framework;
using FlimFlan.WebControls;

namespace ProfileViewTests
{
    [TestFixture]
    public class ProfileViewTests
    {
        [Test]
        public void CreateControl()
        {
            ProfileView p = new ProfileView();
            Assert.IsNotNull(p);
        }

        [Test]
        public void CreateEditControl_ForString_ReturnsTextBox()
        {
            System.Configuration.SettingsProperty property = createProperty("FirstName", typeof(string));

            ControlBuilder builder = new ControlBuilder();
            System.Web.UI.Control control = builder.CreateEditControl(property);

            Assert.IsInstanceOfType(typeof(System.Web.UI.WebControls.TextBox), control);
        }

        [Test]
        public void CreateEditControl_ForBoolean_ReturnsCheckBox()
        {
            System.Configuration.SettingsProperty property = createProperty("IsMarried", typeof(bool));

            ControlBuilder builder = new ControlBuilder();
            System.Web.UI.Control control = builder.CreateEditControl(property);

            Assert.IsInstanceOfType(typeof(System.Web.UI.WebControls.CheckBox), control);
        }

        [Test]
        public void CreateEditControl_SetControlID()
        {
            System.Configuration.SettingsProperty property = createProperty("MyPropertyName", typeof(string));

            ControlBuilder builder = new ControlBuilder();
            System.Web.UI.Control control = builder.CreateEditControl(property);

            Assert.AreEqual("MyPropertyName", control.ID);
        }

        [Test]
        public void CreateDisplayControl_ReturnsLabel()
        {
            System.Configuration.SettingsProperty property = createProperty("IsMarried", typeof(bool));
            
            ControlBuilder builder = new ControlBuilder();
            System.Web.UI.Control control = builder.CreateDisplayControl(property);

            Assert.IsInstanceOfType(typeof(System.Web.UI.WebControls.Label), control);
        }

        [Test]
        public void CreateDisplayControl_SetControlID()
        {
            System.Configuration.SettingsProperty property = createProperty("IsMarried", typeof(bool));

            ControlBuilder builder = new ControlBuilder();
            System.Web.UI.Control control = builder.CreateDisplayControl(property);

            Assert.AreEqual("IsMarried", control.ID);
        }

        private static System.Configuration.SettingsProperty createProperty(string propertyName, Type propertyType)
        {
            System.Configuration.SettingsProperty property = new System.Configuration.SettingsProperty(propertyName);
            property.PropertyType = propertyType;
            property.IsReadOnly = false;
            return property;
        }

        [Test]
        public void GetValidationType_ForString_ReturnString()
        {
            ControlBuilder builder = new ControlBuilder();
            System.Web.UI.WebControls.ValidationDataType validationType = builder.GetValidationType(typeof(string));

            Assert.AreEqual(System.Web.UI.WebControls.ValidationDataType.String, validationType);
        }

        [Test]
        public void GetValidationType_ForDateTime_ReturnDate()
        {
            ControlBuilder builder = new ControlBuilder();
            System.Web.UI.WebControls.ValidationDataType validationType = builder.GetValidationType(typeof(DateTime));

            Assert.AreEqual(System.Web.UI.WebControls.ValidationDataType.Date, validationType);
        }

        [Test]
        public void GetValidationType_ForIntegerTypes_ReturnInteger()
        {
            ControlBuilder builder = new ControlBuilder();
            Type[] integerTypes = new Type[] { typeof(Byte), typeof(SByte),
                typeof(Int16), typeof(Int32), typeof(Int64),
                typeof(UInt16), typeof(UInt32), typeof(UInt64) };
            foreach (Type integerType in integerTypes)
            {
                System.Web.UI.WebControls.ValidationDataType validationType = builder.GetValidationType(integerType);

                Assert.AreEqual(System.Web.UI.WebControls.ValidationDataType.Integer, validationType, integerType.FullName + " should return ValidationDataType.Integer.");
            }
        }

        [Test]
        public void GetValidationType_ForDecimalTypes_ReturnDouble()
        {
            ControlBuilder builder = new ControlBuilder();
            Type[] integerTypes = new Type[] { typeof(Single), typeof(Double), typeof(Decimal) };
            foreach (Type integerType in integerTypes)
            {
                System.Web.UI.WebControls.ValidationDataType validationType = builder.GetValidationType(integerType);

                Assert.AreEqual(System.Web.UI.WebControls.ValidationDataType.Double, validationType, integerType.FullName + " should return ValidationDataType.Double.");
            }
        }

        [Test]
        public void GetValidationType_ForCustomType_ReturnString()
        {
            ControlBuilder builder = new ControlBuilder();
            // use the test class as the custom type
            System.Web.UI.WebControls.ValidationDataType validationType = builder.GetValidationType(this.GetType());

            Assert.AreEqual(System.Web.UI.WebControls.ValidationDataType.String, validationType);
        }

        [Test]
        public void CreateValidationControl_ForString_ReturnNull()
        {
            System.Configuration.SettingsProperty property = createProperty("MyPropertyName", typeof(string));

            ControlBuilder builder = new ControlBuilder();
            System.Web.UI.WebControls.BaseValidator validator = builder.CreateValidationControl(property);

            Assert.IsNull(validator);
        }

        [Test]
        public void CreateValidationControl_ForInteger_ReturnComparer()
        {
            System.Configuration.SettingsProperty property = createProperty("MyPropertyName", typeof(Int32));

            ControlBuilder builder = new ControlBuilder();
            System.Web.UI.WebControls.BaseValidator validator = builder.CreateValidationControl(property);

            Assert.IsInstanceOfType(typeof(System.Web.UI.WebControls.CompareValidator), validator);
        }

    }
}

#endif
using System;
using System.Windows.Forms;
using FlimFlan.OneNote;

namespace AddInTester
{
    public partial class Form1 : Form, IDataService
    {
        private Controller controller;

        public Form1()
        {
            InitializeComponent();
            txtParameter.Text = defaultPageId;
            txtPageContent.Text = defaultPageContent.Replace("\n", Environment.NewLine);
            txtHierarchy.Text = defaultHierarchyContent.Replace("\n", Environment.NewLine);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            controller = new Controller(new FormFactory(), this);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            controller.GoToPage(txtParameter.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            controller.CurrentPageChanged(txtParameter.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            controller.ContentUpdated(txtParameter.Text);
        }

        bool showPage = true;
        private void button4_Click(object sender, EventArgs e)
        {
            showPage = !showPage;
            controller.ChangeDisplayMode(showPage);
        }

        public string GetPageContent(string pageId)
        {
            return txtPageContent.Text;
        }

        public string GetHierarchy()
        {
            return txtHierarchy.Text;
        }

        private void dataSourceSelectionChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                controller = new Controller(new FormFactory(), new OneNoteDataService());
            }
            else
            {
                controller = new Controller(new FormFactory(), this);
            }
        }

        private const string defaultPageId = @"{A0CADA2E-A5E9-484B-97BD-2B6209096999}{1}{B0}";

        private const string defaultPageContent = @"<?xml version=""1.0""?>
<one:Page xmlns:one=""http://schemas.microsoft.com/office/onenote/2007/onenote"" ID=""{A0CADA2E-A5E9-484B-97BD-2B6209096999}{1}{B0}"" name=""Test Page"" dateTime=""2007-01-30T23:57:52.000Z"" lastModifiedTime=""2007-01-30T23:58:03.000Z"" isCurrentlyViewed=""true"">
  <one:PageSettings RTL=""false"" color=""automatic"">
    <one:PageSize>
      <one:Automatic />
    </one:PageSize>
    <one:RuleLines visible=""false"" />
  </one:PageSettings>
  <one:Title style=""font-family:Calibri;font-size:17.0pt"" lang=""en-US"">
    <one:OE author=""Joshua Flanagan"" lastModifiedBy=""Joshua Flanagan"" creationTime=""2007-01-30T23:57:58.000Z"" lastModifiedTime=""2007-01-30T23:58:01.000Z"" objectID=""{DABA9CA6-7F3F-4F5F-A0DC-E8066EBB9AB1}{15}{B0}"" alignment=""left"">
      <one:T><![CDATA[Test Page]]></one:T>
    </one:OE>
  </one:Title>
</one:Page>";

        private const string defaultHierarchyContent = @"<?xml version=""1.0""?>
<one:Notebooks xmlns:one=""http://schemas.microsoft.com/office/onenote/2007/onenote"">
  <one:Notebook name=""Work Notebook"" nickname=""Work Notebook"" ID=""{B5BD8469-14A7-4FE2-8AA8-CBC88FF419E9}{1}{B0}"" >
    <one:Section name=""Research"" ID=""{3958B36B-E70A-02BD-1931-050999DC5DC2}{1}{B0}"">
      <one:Page ID=""{76F1742E-DF83-4313-8638-6C510EB108F9}{1}{B0}"" name=""About this section""  />
    </one:Section>
    <one:Section name=""Travel"" ID=""{55065445-BA76-07C0-3FFA-4924159B97AC}{1}{B0}"" >
      <one:Page ID=""{54F8A4BA-EF95-47C8-B83F-BE438D998FAA}{1}{B0}"" name=""About this section"" />
      <one:Page ID=""{48AD35E2-DDB8-4D40-B0A0-E374F5D3A3E2}{1}{B0}"" name=""Trip 1"" />
      <one:Page ID=""{E1820F69-002F-44D3-892F-0CC4F4674432}{1}{B0}"" name=""Transportation"" />
    </one:Section>
  </one:Notebook>
  <one:Notebook name=""Personal Notebook"" nickname=""Personal Notebook"" ID=""{BA56AFAB-A115-4BB5-8C62-616ED8746463}{1}{B0}""  isCurrentlyViewed=""true"">
    <one:Section name=""Personal information"" ID=""{464161B4-DECB-0AE8-3C4F-D0518B1D652E}{1}{B0}"" isCurrentlyViewed=""true"">
      <one:Page ID=""{14C6DE51-746F-4156-8C7E-E04197A0F2E1}{1}{B0}"" name=""Medical Information"" />
      <one:Page ID=""{A0CADA2E-A5E9-484B-97BD-2B6209096999}{1}{B0}"" name=""Test Page"" isCurrentlyViewed=""true"" />
    </one:Section>
  </one:Notebook>
</one:Notebooks>";
    }
}
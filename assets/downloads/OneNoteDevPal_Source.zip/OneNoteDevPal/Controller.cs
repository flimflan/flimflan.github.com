using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Xml;

namespace FlimFlan.OneNote
{
    public class Controller
    {
        private IDataService dataService;
        private IMainFormView form = null;
        private object gateway = new object();
        private bool formDisplayed = false;
        private IFormFactory formFactory;

        private string currentPageId;
        private string currentPageContent;
        private string currentHierarchyContent;
        private HierarchyNode[] hierarchyTable;
        private bool showingPageContent;

        public Controller(IFormFactory formFactory, IDataService dataService)
        {
            this.formFactory = formFactory;
            this.dataService = dataService;
        }

        //TODO: Refactor so this property is no longer needed
        public string CurrentPageId
        {
            get { return currentPageId; }
        }

        public void GoToPage(string pageId)
        {
            refreshDisplay(pageId);  
        }
        
        public void CurrentPageChanged(string pageId)
        {
            if (formDisplayed)
            {
                refreshDisplay(pageId);
            }
        }

        public void ContentUpdated(string objectId)
        {
        }


        private void refreshDisplay(string pageId)
        {
            ensureFormExists();

            currentPageId = pageId;
            currentPageContent = dataService.GetPageContent(currentPageId);
            currentHierarchyContent = dataService.GetHierarchy();

            updateHierarchyTable();

            updateContent();
        }

        public void ChangeDisplayMode(bool showPageContent)
        {
            if (showPageContent != showingPageContent)
            {
                showingPageContent = showPageContent;
                updateContent();
            }
        }

        private void updateContent()
        {
            string content;
            if (showingPageContent)
            {
                content = currentPageContent;
            }
            else
            {
                content = currentHierarchyContent;
            }

            content = formatXml(content);
            form.Update(hierarchyTable, content);
        }

        private void updateHierarchyTable()
        {
            List<HierarchyNode> hierarchy = new List<HierarchyNode>();

            XmlDocument xmlDoc = new XmlDocument();
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
            nsmgr.AddNamespace("o", "http://schemas.microsoft.com/office/onenote/2007/onenote");
            xmlDoc.LoadXml(currentHierarchyContent);

            XmlNode thisPage = xmlDoc.SelectSingleNode(String.Format("//o:Page[@ID='{0}']", currentPageId), nsmgr);
            if (thisPage == null) return;

            XmlNode currentNode = thisPage;
            while (currentNode != null && currentNode.LocalName != "Notebooks")
            {
                XmlAttribute nameAttribute = currentNode.Attributes["name"];
                string nodeName = nameAttribute != null ? nameAttribute.Value : null;
                XmlAttribute idAttribute = currentNode.Attributes["ID"];
                string nodeId = idAttribute != null ? idAttribute.Value : null;
                string level = currentNode.LocalName;
                if (level == "Page")
                {
                    XmlAttribute subPageAttribute = currentNode.Attributes["isSubPage"];
                    if (subPageAttribute != null && subPageAttribute.Value == "true")
                    {
                        level = "SubPage";
                    }
                }
                hierarchy.Add(new HierarchyNode(level, nodeName, nodeId));
                currentNode = currentNode.ParentNode;
            }
            hierarchyTable = hierarchy.ToArray();
        }


        private void ensureFormExists()
        {
            if (form == null)
            {
                lock (gateway)
                {
                    if (form == null)
                    {
                        initializeFormState();
                        DevPal.Output("Creating MainForm");
                        form = formFactory.CreateMainForm(this);
                        Thread formThread = new Thread(showForm);
                        formThread.Name = "FormThread";
                        formThread.IsBackground = true;
                        formThread.SetApartmentState(ApartmentState.STA);
                        formDisplayed = true;
                        formThread.Start();
                    }
                }
            }
        }

        private void initializeFormState()
        {
            showingPageContent = true;
        }

        private void showForm()
        {
            DevPal.Output("Running MainForm");
            form.Run();
            lock (gateway)
            {
                DevPal.Output("Destroying MainForm");
                form = null;
                formDisplayed = false;
            }
        }

        private static string formatXml(string xml)
        {
            using (StringWriter sw = new StringWriter())
            {
                XmlTextWriter xw = new XmlTextWriter(sw);
                xw.Formatting = Formatting.Indented;
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xml);
                doc.WriteContentTo(xw);
                return sw.ToString();
            }
        }

    }
}

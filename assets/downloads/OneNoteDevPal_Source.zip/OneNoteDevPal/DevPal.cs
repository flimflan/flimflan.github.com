using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Office.Interop.OneNote;
// Initial add-in framework based on the guide published at https://blogs.msdn.com/descapa/archive/2006/08/31/734298.aspx

namespace FlimFlan.OneNote
{
    [Guid("FF09BA17-10A8-47d8-BCAA-69DE18B115F3")]
    public class DevPal : IOneNoteAddIn
    {
        private Controller controller;
        public DevPal()
        {
            controller = new Controller(new FormFactory(), new OneNoteDataService());
        }

        public bool OnClick([In] string bstrActivePageID)
        {
            Output("OnClick {0}", bstrActivePageID);
            controller.GoToPage(bstrActivePageID);
            return true;
        }

        public bool OnEvent([In] OneNoteAddIn_Event evt, [In] string bstrParameter)
        {
            Output("{0} {1}", evt,  bstrParameter);

            switch(evt.ToString())
            {
                case "evtAddInHierarchyChange":
                    // refresh the page that is displayed
                    controller.ContentUpdated(bstrParameter);
                    break;
                case "evtAddInNavigation":
                    controller.CurrentPageChanged(bstrParameter);
                    break;
            }
            return true;
        }

        public static void Output(string format, params object[] args)
        {
            Thread currentThread = Thread.CurrentThread;
            Process currentProcess = Process.GetCurrentProcess();

            string formattedMessage =
                String.Format("{0}({1}) {2}({3}): {4}", currentProcess.ProcessName, currentProcess.Id,
                              currentThread.Name ?? "<Unnamed>", currentThread.ManagedThreadId, String.Format(format, args));
            Trace.WriteLine(formattedMessage);
        }
    }
}
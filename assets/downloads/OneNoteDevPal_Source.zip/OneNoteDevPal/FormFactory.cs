namespace FlimFlan.OneNote
{
    public class FormFactory : IFormFactory
    {
        public IMainFormView CreateMainForm(Controller controller)
        {
            return new MainForm(controller);
        }
    }
}

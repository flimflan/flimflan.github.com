namespace FlimFlan.OneNote
{
    public class HierarchyNode
    {
        private string level;
        private string name;
        private string id;


        public HierarchyNode(string level, string name, string id)
        {
            this.level = level;
            this.name = name;
            this.id = id;
        }

        public string Level
        {
            get { return level; }
        }

        public string Name
        {
            get { return name; }
        }

        public string Id
        {
            get { return id; }
        }
    }
}


namespace FlimFlan.OneNote
{
    public interface IDataService
    {
        string GetPageContent(string pageId);
        string GetHierarchy();
    }
}

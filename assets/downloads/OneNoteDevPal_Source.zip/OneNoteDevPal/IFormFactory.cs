
namespace FlimFlan.OneNote
{
    public interface IFormFactory
    {
        IMainFormView CreateMainForm(Controller controller);
    }
}


namespace FlimFlan.OneNote
{
    public interface IMainFormView
    {
        void Run();
        void Update(HierarchyNode[] hierarchy, string content);
    }
}

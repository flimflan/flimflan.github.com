using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace FlimFlan.OneNote
{
    public partial class MainForm : Form, IMainFormView
    {
        string saveFolder = null;
        private Controller controller;

        static MainForm()
        {
            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e) { DevPal.Output("UnhandledException: {0}", e.ExceptionObject); };
            Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs e) { DevPal.Output("ThreadException: {0}", e.Exception); };
        }

        public MainForm(Controller controller)
        {
            this.controller = controller;
            InitializeComponent();
        }

        public MainForm() : this(null){}
        
        public void Update(HierarchyNode[] hierarchy, string content)
        {
            DevPal.Output("Updating form");

            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { Update(hierarchy, content); });
                return;
            }
            PageContentDisplay.Cursor = Cursors.WaitCursor;

            dataGridView1.DataSource = hierarchy;

            applySyntaxHighlighting(content, optPage.Checked);

            PageContentDisplay.Cursor = Cursors.Default;
        }

        public void Run()
        {
            Application.Run(this);
        }

        private void applySyntaxHighlighting(string content, bool showingPage)
        { // could probably improve perf by writing rtf codes directly
            PageContentDisplay.SuspendLayout();
            PageContentDisplay.Text = content;
            Font bold = new Font(PageContentDisplay.Font, FontStyle.Bold);
            PageContentDisplay.SelectAll();
            PageContentDisplay.SelectionColor = Color.Maroon;
            int startPosition = 0;
            while (startPosition >= 0)
            {
                int found = PageContentDisplay.Find(new char[] { '<', '>', '=', '/', '"' }, startPosition);
                if (found >= 0)
                {
                    PageContentDisplay.SelectionStart = found;
                    PageContentDisplay.SelectionLength = 1;
                    PageContentDisplay.SelectionColor = Color.Blue;
                    startPosition = found + 1;
                }
                else
                {
                    startPosition = found;
                }
            }

            string findStrings = @"""(?<string>.*?)""";
            MatchCollection matches = Regex.Matches(PageContentDisplay.Text, findStrings, RegexOptions.Multiline);
            for (int i = matches.Count - 1; i >= 0; i--)
            {
                Group foundString = matches[i].Groups["string"];
                PageContentDisplay.SelectionStart = foundString.Index;
                PageContentDisplay.SelectionLength = foundString.Length;
                PageContentDisplay.SelectionColor = Color.Black;
                //   PageContentDisplay.SelectionFont = bold;
            }

            if (showingPage)
            {
                string findCDATA = @"<!\[CDATA\[(?<string>.*?)]]>";
                matches = Regex.Matches(PageContentDisplay.Text, findCDATA, RegexOptions.Singleline);
                for (int i = matches.Count - 1; i >= 0; i--)
                {
                    PageContentDisplay.SelectionStart = matches[i].Index;
                    PageContentDisplay.SelectionLength = matches[i].Length;
                    PageContentDisplay.SelectionColor = Color.Blue;

                    Group foundString = matches[i].Groups["string"];
                    PageContentDisplay.SelectionStart = foundString.Index;
                    PageContentDisplay.SelectionLength = foundString.Length;
                    PageContentDisplay.SelectionColor = Color.Black;
                    PageContentDisplay.SelectionFont = bold;
                }
            }
            else
            {
                string findNames = @"\sname=""(?<string>.*?)""";
                matches = Regex.Matches(PageContentDisplay.Text, findNames, RegexOptions.Singleline);
                for (int i = matches.Count - 1; i >= 0; i--)
                {
                    Group foundString = matches[i].Groups["string"];
                    PageContentDisplay.SelectionStart = foundString.Index;
                    PageContentDisplay.SelectionLength = foundString.Length;
                    //PageContentDisplay.SelectionColor = Color.Red;
                    PageContentDisplay.SelectionFont = bold;
                }

            }

            string findOneNoteElements = @"(?<!/)one:(?<string>\w+)";
            matches = Regex.Matches(PageContentDisplay.Text, findOneNoteElements, RegexOptions.Singleline);
            for (int i = matches.Count - 1; i >= 0; i--)
            {
                Group foundString = matches[i].Groups["string"];
                PageContentDisplay.SelectionStart = foundString.Index;
                PageContentDisplay.SelectionLength = foundString.Length;
                PageContentDisplay.SelectionColor = Color.Green;
                PageContentDisplay.SelectionFont = bold;
            }


            string findID = @"\sID=""(?<string>.*?)""";
            matches = Regex.Matches(PageContentDisplay.Text, findID, RegexOptions.Singleline);
            for (int i = matches.Count - 1; i >= 0; i--)
            {
                Group foundString = matches[i].Groups["string"];
                PageContentDisplay.SelectionStart = foundString.Index;
                PageContentDisplay.SelectionLength = foundString.Length;
                PageContentDisplay.SelectionColor = Color.Red;
                PageContentDisplay.SelectionFont = bold;
            }
            if (showingPage)
            {
                PageContentDisplay.Select(0, 1);
                PageContentDisplay.ScrollToCaret();
            }
            else
            {
                PageContentDisplay.Find(String.Format(@"ID=""{0}""", controller.CurrentPageId));
                PageContentDisplay.ScrollToCaret();
            }
            PageContentDisplay.ResumeLayout();
        }

        private void CopyButton_Click(object sender, EventArgs e)
        {
            DevPal.Output("CopyButton");
            Clipboard.SetText(PageContentDisplay.Text);
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            
            DevPal.Output("SaveButton");
            string pagePath = getFileNameForPage(controller.CurrentPageId);
            if (pagePath == null) return;
            File.WriteAllText(pagePath, PageContentDisplay.Text);
        }

        private string getFileNameForPage(string pageId)
        {
            if (String.IsNullOrEmpty(pageId)) return null;
            ensureSaveFolderSelected();
            if (saveFolder == null) return null;
            string fileName = optPage.Checked
                                  ? Path.Combine(saveFolder, pageId + ".xml")
                                  : Path.Combine(saveFolder, "hierarchy.xml");
            return fileName;
        }

        private void ensureSaveFolderSelected()
        {
            if (saveFolder != null) return;
            if (FolderBrowser.ShowDialog() != DialogResult.OK) return;
            saveFolder = FolderBrowser.SelectedPath;
        }

        private void displayOptionChanged(object sender, EventArgs e)
        {
            controller.ChangeDisplayMode(optPage.Checked);
        }

        private void ShowHelp(object sender, HelpEventArgs hlpevent)
        {
//            AssemblyName assemblyName = Assembly.GetExecutingAssembly().GetName();
//            string aboutFormat = @"{0}
//{1}
//
//Copyright 2007 Joshua Flanagan
//http://flimflan.com/blog
//
//Icon 
//";

//            MessageBox.Show(String.Format(aboutFormat, assemblyName.Name, assemblyName.Version), "About OneNoteDevPal");
            new AboutBox().ShowDialog();
        }

    }
}
using Microsoft.Office.Interop.OneNote;

namespace FlimFlan.OneNote
{
    public class OneNoteDataService: IDataService
    {
        private Application app = new ApplicationClass();

        public string GetPageContent(string pageId)
        {
            string content;
            app.GetPageContent(pageId, out content, PageInfo.piBasic);
            return content;

        }

        public string GetHierarchy()
        {
            string hierarchy;
            app.GetHierarchy(null, HierarchyScope.hsPages, out hierarchy);
            return hierarchy;
        }
    }
}

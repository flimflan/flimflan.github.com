using System;
using System.Text.RegularExpressions;
using FlimFlan.ReadableRex;

namespace Driver
{
    public class Program
    {
        public static void Main()
        {
            Pattern SocialSecurityNumber = Pattern.With.AtBeginning
                .Digit.Repeat.Exactly(3)
                .Literal("-").Repeat.Optional
                .Digit.Repeat.Exactly(2)
                .Literal("-").Repeat.Optional
                .Digit.Repeat.Exactly(4)
                .AtEnd;

            Console.WriteLine(SocialSecurityNumber);

            string potential1 = "111-22-3344";
            string potential2 = "111-322-3344";
            string potential3 = "111223344";
            Console.WriteLine("{0}: {1}", potential1, Regex.IsMatch(potential1, SocialSecurityNumber));
            Console.WriteLine("{0}: {1}", potential2, Regex.IsMatch(potential2, SocialSecurityNumber));
            Console.WriteLine("{0}: {1}", potential3, Regex.IsMatch(potential3, SocialSecurityNumber));
        }
    }
}

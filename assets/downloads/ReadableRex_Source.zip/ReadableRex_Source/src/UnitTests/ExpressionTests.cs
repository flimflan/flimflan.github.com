using System;
using NUnit.Framework;
using FlimFlan.ReadableRex;

namespace UnitTests
{
    [TestFixture]
    public class ExpressionTests
    {
        [Test]
        public void Create()
        {
            Pattern expression = new Pattern("");
            Assert.IsNotNull(expression, "Should have created an instance.");
        }

        [Test]
        public void ExplicitCtorLiteral()
        {
            Pattern ex = new Pattern("A");
            string output = ex.ToString();
            Assert.AreEqual("A", output);
        }

        [Test]
        public void Literal()
        {
            Pattern ex = Pattern.With.Literal("A");
            string output = ex.ToString();
            Assert.AreEqual("A", output);
        }


        [Test]
        public void LiteralWithReservedCharacters()
        {
            Pattern ex = Pattern.With.Literal(@"BEGIN!@#%&/.$^{[(|)]}*+?\END");
            string output = ex.ToString();
            Assert.AreEqual(@"BEGIN!@#%&/\.\$\^\{\[\(\|\)]}\*\+\?\\END", output);
        }

        [Test]
        public void Chained()
        {
            Pattern ex = Pattern.With.Literal("A").Literal("B");
            string output = ex.ToString();
            Assert.AreEqual("AB", output);
        }

        [Test]
        public void Word()
        {
            Pattern ex = Pattern.With.Word;
            string output = ex.ToString();
            Assert.AreEqual(@"\w", output);
        }

        [Test]
        public void Digit()
        {
            Pattern ex = Pattern.With.Digit;
            string output = ex.ToString();
            Assert.AreEqual(@"\d", output);
        }

        [Test]
        public void WhiteSpace()
        {
            Pattern ex = Pattern.With.WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\s", output);
        }

        [Test]
        public void Not()
        {
            Pattern ex = Pattern.With.NegatedSet(Pattern.With.WhiteSpace);
            string output = ex.ToString();
            Assert.AreEqual(@"[^\s]", output);
        }

        [Test]
        public void ChainedNot()
        {
            Pattern ex = Pattern.With.Digit.NegatedSet(Pattern.With.WhiteSpace.Word).Digit;
            string output = ex.ToString();
            Assert.AreEqual(@"\d[^\s\w]\d", output);
        }

        [Test]
        public void NonWhiteSpace()
        {
            Pattern ex = Pattern.With.NonWhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\S", output);
        }

        [Test]
        public void NonWord()
        {
            Pattern ex = Pattern.With.NonWord;
            string output = ex.ToString();
            Assert.AreEqual(@"\W", output);
        }

        [Test]
        public void NonDigit()
        {
            Pattern ex = Pattern.With.NonDigit;
            string output = ex.ToString();
            Assert.AreEqual(@"\D", output);
        }

        [Test]
        public void Any()
        {
            Pattern ex = Pattern.With.Anything;
            string output = ex.ToString();
            Assert.AreEqual(@".", output);
        }

        [Test]
        public void Repeat_ZeroOrMore()
        {
            Pattern ex = Pattern.With.Digit.Repeat.ZeroOrMore;
            string output = ex.ToString();
            Assert.AreEqual(@"\d*", output);
        }

        [Test]
        public void Repeat_ZeroOrMoreCompound()
        {
            Pattern ex = Pattern.With.Group(Pattern.With.Digit.Word.Digit).Repeat.ZeroOrMore;
            string output = ex.ToString();
            Assert.AreEqual(@"(\d\w\d)*", output);
        }

        [Test]
        public void Repeat_ZeroOrMoreWithPrecedingExpression()
        {
            Pattern ex = Pattern.With.Word.Group(Pattern.With.Digit.Word.Digit).Repeat.ZeroOrMore;
            string output = ex.ToString();
            Assert.AreEqual(@"\w(\d\w\d)*", output);
        }

        [Test]
        public void Repeat_ZeroOrMoreWithTrailingExpression()
        {
            Pattern ex = Pattern.With.Group(Pattern.With.Digit.Word.Digit).Repeat.ZeroOrMore.Digit;
            string output = ex.ToString();
            Assert.AreEqual(@"(\d\w\d)*\d", output);
        }

        [Test]
        public void Repeat_Exactly()
        {
            Pattern ex = Pattern.With.Digit.Repeat.Exactly(3);
            string output = ex.ToString();
            Assert.AreEqual(@"\d{3}", output);
        }

        [Test]
        public void Repeat_ExactlyChain_OnlyRepeatsLastItem()
        {
            Pattern ex = Pattern.With.Word.WhiteSpace.Digit.Repeat.Exactly(3);
            string output = ex.ToString();
            Assert.AreEqual(@"\w\s\d{3}", output);
        }

        [Test]
        public void Repeat_ExactlyGrouped_RepeatsEntireGroup()
        {
            Pattern ex = Pattern.With.Group(Pattern.With.Word.WhiteSpace.Digit).Repeat.Exactly(3);
            string output = ex.ToString();
            Assert.AreEqual(@"(\w\s\d){3}", output);
        }

        [Test]
        public void LiteralRegEx()
        {
            Pattern ex = Pattern.With.RegEx(@"\w([a-z]*)");
            string output = ex.ToString();
            Assert.AreEqual(@"\w([a-z]*)", output);
        }

        [Test]
        public void Group()
        {
            Pattern ex = Pattern.With.Word.Group(Pattern.With.WhiteSpace.Digit.WhiteSpace).NonDigit;
            string output = ex.ToString();
            Assert.AreEqual(@"\w(\s\d\s)\D", output);
        }

        [Test]
        public void NamedGroup()
        {
            Pattern ex = Pattern.With.Word.NamedGroup("age", Pattern.With.WhiteSpace.Digit.WhiteSpace).NonDigit;
            string output = ex.ToString();
            Assert.AreEqual(@"\w(?<age>\s\d\s)\D", output);
        }

        [Test]
        public void Repeat_OneOrMore()
        {
            Pattern ex = Pattern.With.Digit.Repeat.OneOrMore;
            string output = ex.ToString();
            Assert.AreEqual(@"\d+", output);
        }

        [Test]
        public void Repeat_Optional()
        {
            Pattern ex = Pattern.With.Digit.Repeat.Optional;
            string output = ex.ToString();
            Assert.AreEqual(@"\d?", output);
        }

        [Test]
        public void Repeat_AtLeast()
        {
            Pattern ex = Pattern.With.Digit.Repeat.AtLeast(3);
            string output = ex.ToString();
            Assert.AreEqual(@"\d{3,}", output);
        }

        [Test]
        public void Repeat_AtMost()
        {
            Pattern ex = Pattern.With.Digit.Repeat.AtMost(3);
            string output = ex.ToString();
            Assert.AreEqual(@"\d{,3}", output);
        }

        [Test]
        public void Repeat_InRange()
        {
            Pattern ex = Pattern.With.Digit.Repeat.InRange(3, 5);
            string output = ex.ToString();
            Assert.AreEqual(@"\d{3,5}", output);
        }

        [Test]
        public void Repeat_LazyZeroOrMore()
        {
            Pattern ex = Pattern.With.Digit.Repeat.Lazy.ZeroOrMore;
            string output = ex.ToString();
            Assert.AreEqual(@"\d*?", output);
        }

        [Test]
        public void Repeat_LazyChainedOneOrMore()
        {
            Pattern ex = Pattern.With.Digit.Word.Repeat.Lazy.OneOrMore.WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\d\w+?\s", output);
        }

        [Test]
        public void Repeat_LazyExactly()
        {
            Pattern ex = Pattern.With.Digit.Repeat.Lazy.Exactly(3);
            string output = ex.ToString();
            Assert.AreEqual(@"\d{3}?", output);
        }

        [Test]
        public void Repeat_LazyAtLeast()
        {
            Pattern ex = Pattern.With.Digit.Repeat.Lazy.AtLeast(3);
            string output = ex.ToString();
            Assert.AreEqual(@"\d{3,}?", output);
        }

        [Test]
        public void Repeat_LazyOptional()
        {
            Pattern ex = Pattern.With.Digit.Repeat.Lazy.Optional;
            string output = ex.ToString();
            Assert.AreEqual(@"\d??", output);
        }

        [Test]
        public void Repeat_LazyInRange()
        {
            Pattern ex = Pattern.With.Digit.Repeat.Lazy.InRange(2, 4);
            string output = ex.ToString();
            Assert.AreEqual(@"\d{2,4}?", output);
        }

        [Test,ExpectedException(typeof(InvalidOperationException))]
        public void Repeat_LazyAtMost()
        {
            Pattern ex = Pattern.With.Digit.Repeat.Lazy.AtMost(3);
            string output = ex.ToString();
        }

        [Test]
        public void Phrase()
        {
            Pattern ex = Pattern.With.Digit.Phrase(Pattern.With.Word.WhiteSpace).Word;
            string output = ex.ToString();
            Assert.AreEqual(@"\d(?:\w\s)\w", output);
        }

        [Test]
        public void Set()
        {
            Pattern ex = Pattern.With.WhiteSpace.Set(Pattern.With.Word.Digit).WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\s[\w\d]\s", output);
        }

        [Test]
        public void SetRange()
        {
            Pattern ex = Pattern.With.WhiteSpace.Set(Range.Of('a', 'z')).WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\s[a-z]\s", output);
        }

        [Test]
        public void SetRangeChained()
        {
            Pattern ex = Pattern.With.WhiteSpace.Set(Range.Of('a', 'z').WhiteSpace).WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\s[a-z\s]\s", output);
        }

        [Test]
        public void SetRangeNumeric()
        {
            Pattern ex = Pattern.With.WhiteSpace.Set(Range.Of(1, 5)).WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\s[1-5]\s", output);
        }

        [Test]
        public void Concatenation()
        {
            Pattern exA = new Pattern("A");
            Pattern exB = new Pattern("B");
            Pattern both = exA + exB;
            string output = both.ToString();
            Assert.AreEqual("AB", output);
        }

        [Test]
        public void SetMultipleRanges()
        {
            Pattern ex = Pattern.With.WhiteSpace.Set(Range.Of('a', 'z') + Range.Of('A', 'Z') + Range.Of(0, 9)).WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\s[a-zA-Z0-9]\s", output);
        }

        [Test]
        public void SetRangeLetter()
        {
            Pattern ex = Pattern.With.WhiteSpace.Set(Range.AnyLetter.Digit).WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\s[a-zA-Z\d]\s", output);
        }

        [Test]
        public void SetRangeLowercaseLetter()
        {
            Pattern ex = Pattern.With.WhiteSpace.Set(Range.AnyLowercaseLetter.Digit).WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\s[a-z\d]\s", output);
        }

        [Test]
        public void SetRangeUppercaseLetter()
        {
            Pattern ex = Pattern.With.WhiteSpace.Set(Range.AnyUppercaseLetter.Digit).WhiteSpace;
            string output = ex.ToString();
            Assert.AreEqual(@"\s[A-Z\d]\s", output);
        }

        [Test]
        public void RealWorldExample_PartNumber()
        {
            Pattern partNumber = Pattern.With.AtBeginning
                .Set(Range.Of('a', 'z') + Range.Of('A', 'Z') + Range.Of(0, 9)).Repeat.Exactly(5)
                .AtEnd;
            string output = partNumber.ToString();
            Assert.AreEqual(@"^[a-zA-Z0-9]{5}$", output);

            Pattern partNumberSimpler = Pattern.With.AtBeginning
                .Set(Pattern.With.RegEx("a-zA-Z0-9")).Repeat.Exactly(5)
                .AtEnd;
            output = partNumberSimpler.ToString();
            Assert.AreEqual(@"^[a-zA-Z0-9]{5}$", output);

        }

        [Test]
        public void AlternationOr()
        {
            Pattern ex = Pattern.With.Choice.Either(Pattern.With.Literal("a"), Pattern.With.Literal("b"));
            string output = ex.ToString();
            Assert.AreEqual(@"(a|b)", output);
        }

        [Test]
        public void AlternationOrComplexWithTrailer()
        {
            Pattern ex = Pattern.With.Choice.Either(Pattern.With.Literal("ab"), Pattern.With.Literal("cd")).Literal("ef");
            string output = ex.ToString();
            Assert.AreEqual(@"(ab|cd)ef", output);
        }

        [Test]
        public void AlternationIfPattern()
        {
            Pattern ex = Pattern.With.Choice.If(Pattern.With.Literal("z"), Pattern.With.Literal("a"), Pattern.With.Literal("b"));
            string output = ex.ToString();
            Assert.AreEqual(@"(?(?=z)a|b)", output);
        }

        [Test]
        public void AlternationIfNamedGroup()
        {
            Pattern ex = Pattern.With.Choice.If("firstName", Pattern.With.Literal("a"), Pattern.With.Literal("b"));
            string output = ex.ToString();
            Assert.AreEqual(@"(?(firstName)a|b)", output);
        }

        [Test]
        public void AlternationIfOrdinalGroup()
        {
            Pattern ex = Pattern.With.Choice.If(2, Pattern.With.Literal("a"), Pattern.With.Literal("b"));
            string output = ex.ToString();
            Assert.AreEqual(@"(?(2)a|b)", output);
        }

    }
}

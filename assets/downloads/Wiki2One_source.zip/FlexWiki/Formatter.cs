#region License Statement
// Code copied from the FlexWiki project at http://www.flexwiki.com/

// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// The use and distribution terms for this software are covered by the 
// Common Public License 1.0 (http://opensource.org/licenses/cpl.php)
// which can be found in the file CPL.TXT at the root of this distribution.
// By using this software in any fashion, you are agreeing to be bound by 
// the terms of this license.
//
// You must not remove this notice, or any other, from this software.
#endregion

using System.Text.RegularExpressions;

namespace Wiki2One.FlexWiki
{
    public class Formatter
    {
        public static string s_AZ = "[\\p{Lu}]"; // A-Z
        public static string s_az09 = "[\\p{Ll}\\p{Lt}\\p{Lo}\\p{Nd}]"; // a-z0-9
        public static string s_Az09 = "[\\p{Lu}\\p{Ll}\\p{Lt}\\p{Lo}\\p{Nd}]"; // A-Za-z0-9

        private static string s_bracketedWikiName = "\\[(?:[\\w ]+)\\]"; // \w is a word character (A-z0-9_)
        public static string s_beforeWikiName = "(?<before>^|\\||\\*|'|\\s|\\(|\\{|\\!|\\>)";
        public static string s_afterWikiName = "(?<after>'|\\||\\s|@|$|\\.|,|:|'|;|\\}|\\?|_|\\)|\\!|\\<)";
        private static string s_namespaceName = s_AZ + "[\\w]+";
        private static string s_startsWithMulticaps = "(" + s_AZ + "{2,}" + s_az09 + "+" + s_Az09 + "*)";
        private static string s_startsWithOneCap = "(" + s_AZ + s_az09 + "+" + s_Az09 + "*" + s_AZ + "+" + s_Az09 + "*)";
        private static string s_unbracketedWikiName = "(?:_?" + s_startsWithMulticaps + "|" + s_startsWithOneCap + ")";

        private static string s_unqualifiedWikiName = "(?:" + "(?:" + s_unbracketedWikiName + ")|(?:" + s_bracketedWikiName + ")" + ")";
        private static string s_forcedLocalWikiName = "\\." + s_unqualifiedWikiName;
        private static string s_qualifiedWikiName = "(?:" + s_namespaceName + "\\.)*" + s_unqualifiedWikiName;
        public static string s_wikiName = "(?:" + "(?:" + s_qualifiedWikiName + ")|(?:" + s_unqualifiedWikiName + ")|(?:" + s_forcedLocalWikiName + ")" + ")";
        public static string extractWikiNamesString = s_beforeWikiName + "(?<topic>" + s_wikiName + ")" + s_afterWikiName;
        public static Regex extractWikiNames = new Regex(extractWikiNamesString);

    }
}

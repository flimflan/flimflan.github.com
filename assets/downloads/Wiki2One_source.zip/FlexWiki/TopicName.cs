#region License Statement
// Code copied from the FlexWiki project at http://www.flexwiki.com/

// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// The use and distribution terms for this software are covered by the 
// Common Public License 1.0 (http://opensource.org/licenses/cpl.php)
// which can be found in the file CPL.TXT at the root of this distribution.
// By using this software in any fashion, you are agreeing to be bound by 
// the terms of this license.
//
// You must not remove this notice, or any other, from this software.
#endregion

using System;

namespace Wiki2One.FlexWiki
{
    public class TopicName
    {
        private string _namespace;
        private string _localName;

        public TopicName(string name)
        {
            if (name == null)
            {
                throw new ArgumentException("A null topic name is not legal.");
            }

            int dot = name.LastIndexOf(".");
            _namespace = null;
            if (dot >= 0)
            {
                _namespace = name.Substring(0, dot);
                if (_namespace == "")
                {
                    _namespace = null;
                }
                name = name.Substring(dot + 1);
            }
            _localName = name;

        }


        public string Namespace
        {
            get { return _namespace; }
        }

        public string LocalName
        {
            get { return _localName; }
        }

        public string FormattedName { get { return GetFormattedName(_localName); } }

        public static string GetFormattedName(string localName)
        {
            // basic breaking rule: break between lowercase to uppercase transitions
            // caveat: don't break before first cap
            bool firstCap = true;
            bool lastWasLower = false;
            string formattedName = "";
            string scan = localName;
            for (int i = 0; i < scan.Length; i++)
            {
                char ch = scan[i];
                if (!Char.IsUpper(ch))
                {
                    formattedName += ch;
                    lastWasLower = true;
                    continue;
                }

                if (firstCap)
                {
                    firstCap = false;
                    formattedName += ch;
                    lastWasLower = false;
                    continue;
                }

                if (lastWasLower || ((i + 1) < scan.Length && Char.IsLower(scan[i + 1])))
                {
                    formattedName += ' ';
                }
                formattedName += ch;
                lastWasLower = false;
            }
            return formattedName;
        }

        public override bool Equals(object obj)
        {
            if (this == obj)
            {
                return true;
            }
            TopicName topicName = obj as TopicName;
            if (topicName == null)
            {
                return false;
            }
            return Equals(_namespace, topicName._namespace) && Equals(_localName, topicName._localName);
        }

        public override int GetHashCode()
        {
            return (_namespace != null ? _namespace.GetHashCode() : 0) + 29*_localName.GetHashCode();
        }
    }
}

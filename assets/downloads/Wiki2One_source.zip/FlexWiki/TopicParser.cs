#region License Statement
// Code copied from the FlexWiki project at http://www.flexwiki.com/

// Copyright (c) Microsoft Corporation.  All rights reserved.
//
// The use and distribution terms for this software are covered by the 
// Common Public License 1.0 (http://opensource.org/licenses/cpl.php)
// which can be found in the file CPL.TXT at the root of this distribution.
// By using this software in any fashion, you are agreeing to be bound by 
// the terms of this license.
//
// You must not remove this notice, or any other, from this software.
#endregion

using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Wiki2One.FlexWiki
{
    public class TopicParser
    {

        public static IList<TopicName> ParseTopicLinks(string text)
        {
            IList<TopicName> referencedTopics = new List<TopicName>();

            // TODO: Move Formatter functionality to TopicParser
            MatchCollection wikiNames = Formatter.extractWikiNames.Matches(text);

            List<string> processed = new List<string>();

            foreach (Match m in wikiNames)
            {
                string each = m.Groups["topic"].ToString();
                if (processed.Contains(each))
                {
                    continue;   // skip duplicates
                }

                processed.Add(each);

                TopicName referencedTopic = new TopicName(StripTopicNameEscapes(each));
                referencedTopics.Add(referencedTopic);
            }

            return referencedTopics;
        }

        public static string StripTopicNameEscapes(string v)
        {
            string answer = v;
            answer = answer.Replace("[", "");
            answer = answer.Replace("]", "");
            return answer;
        }

    }
}

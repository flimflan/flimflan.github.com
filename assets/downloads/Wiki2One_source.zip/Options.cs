

namespace Wiki2One
{
    public class Options
    {
        public Options(string defaultNotebookName, string defaultSectionName)
        {
            notebookName = defaultNotebookName;
            sectionName = defaultSectionName;
        }

        private string  wikiRoot;

        public string  WikiRoot
        {
            get { return wikiRoot; }
            set { wikiRoot = value; }
        }

        private string  notebookRoot;

        public string  NotebookRoot
        {
            get { return notebookRoot; }
            set { notebookRoot = value; }
        }

        private string notebookName;

        public string NotebookName
        {
            get { return notebookName; }
            set { notebookName = value; }
        }

        private string  sectionName;

        public string  SectionName
        {
            get { return sectionName; }
            set { sectionName = value; }
        }


    }
}

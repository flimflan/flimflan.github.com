using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using Microsoft.Office.Interop.OneNote;
using Wiki2One.FlexWiki;

namespace Wiki2One
{
    class Program
    {

        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                Console.WriteLine("wiki2one <wikiRoot> [Notebook] [SectionName]");
                return;
            }
            Program p = new Program(LoadOptions(args));
            p.Convert();
        }


        private Options options;
        private Application app;

        public Program(Options options)
        {
            this.options = options;
        }

        private static Options LoadOptions(string[] args)
        {
            Options options = new Options("Wiki2One", String.Format("Import_{0:yyyyMMdd_hhmmss}", DateTime.Now));
            options.WikiRoot = args[0];
            if (args.Length > 1)
            {
                string notebookParam = args[1];
                if (Uri.IsWellFormedUriString(notebookParam, UriKind.Absolute))
                {
                    int lastSlash = notebookParam.LastIndexOf('/');
                    if (lastSlash == (notebookParam.Length - 1))
                    {
                        // use default name
                        options.NotebookName = "Wiki2One";
                        options.NotebookRoot = notebookParam;
                    }
                    else
                    {
                        options.NotebookName = notebookParam.Substring(lastSlash + 1);
                        options.NotebookRoot = notebookParam.Substring(0, lastSlash + 1);
                    }
                } else if (Path.IsPathRooted(notebookParam))
                {
                    options.NotebookName = Path.GetFileNameWithoutExtension(notebookParam);
                    options.NotebookRoot = Path.GetDirectoryName(notebookParam);
                }
                else
                {
                    options.NotebookName = notebookParam;
                    options.NotebookRoot = null;
                }
            }
            if (args.Length > 2)
            {
                options.SectionName = args[2];
            }
            return options;
        }

        private void Convert()
        {
            app = new Application();
            if (options.NotebookRoot == null)
            {
                options.NotebookRoot = getNotebooksPath();
            }
            EnsureSectionExists();
            IDictionary<string, WikiPage> pages = IdentifyPages(options.WikiRoot);
            ImportPageContent(pages);

            Marshal.ReleaseComObject(app);
            app = null;
        }

        private void EnsureSectionExists()
        {
            string updateFormat = @"<?xml version=""1.0"" ?> 
<one:Notebooks xmlns:one=""http://schemas.microsoft.com/office/onenote/2007/onenote""> 
    <one:Notebook name=""{0}"" path=""{1}"">
        <one:Section name=""{2}"" />
    </one:Notebook> 
</one:Notebooks> 
";
            string newNotebookPath = Path.Combine(options.NotebookRoot, options.NotebookName);
            string updatedHierarchy = String.Format(updateFormat, options.NotebookName, newNotebookPath, options.SectionName);
            app.UpdateHierarchy(updatedHierarchy);
        }

        private string getNotebooksPath()
        {
            string hierarchy;
            app.GetHierarchy(null, HierarchyScope.hsNotebooks, out hierarchy);

            XmlNamespaceManager nsmgr;
            XmlDocument xmlDoc = GetDocument(hierarchy, out nsmgr);

            XmlNodeList notebooks = xmlDoc.SelectNodes("/o:Notebooks/o:Notebook", nsmgr);
            string firstPath = notebooks[0].Attributes["path"].Value;
            return Path.GetDirectoryName(firstPath);
        }

        private static XmlDocument GetDocument(string content, out XmlNamespaceManager namespaceManager)
        {
            string oneNoteNamespace = "http://schemas.microsoft.com/office/onenote/2007/onenote";
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(content);
            namespaceManager = new XmlNamespaceManager(xmlDoc.NameTable);
            namespaceManager.AddNamespace("o", oneNoteNamespace);
            return xmlDoc;
        }

        private IDictionary<string, WikiPage> IdentifyPages(string rootFolder)
        {
            Dictionary<string, WikiPage> pageLinks = new Dictionary<string, WikiPage>();

            string[] allFiles = Directory.GetFiles(rootFolder, "*.wiki");
            foreach(string file in allFiles)
            {
                string pageName = Path.GetFileNameWithoutExtension(file);
                if (pageName.StartsWith("_")) continue;
                string[] content = File.ReadAllLines(file);

                string pageId = GetPageIdForName(pageName);
                string linkToPage;
                app.GetHyperlinkToObject(pageId, null, out linkToPage);

                pageLinks.Add(pageName, new WikiPage(pageId, content, linkToPage));
            }
            return pageLinks;
        }

        private void ImportPageContent(IDictionary<string, WikiPage> pages)
        {
            foreach (KeyValuePair<string, WikiPage> page in pages)
            {
                string converted = ConvertContentToOneXml(page.Value.Content, pages);
                string pageTemplate = @"<one:Page xmlns:one=""http://schemas.microsoft.com/office/onenote/2007/onenote"" ID=""{0}"">{1}</one:Page>";
                string newContent = String.Format(pageTemplate, page.Value.Id, converted);
                app.UpdatePageContent(newContent, DateTime.MinValue);
            }
        }

        private string GetPageIdForName(string pageName)
        {
            string currentHierarchy;
            app.GetHierarchy(null, HierarchyScope.hsPages, out currentHierarchy);

            XmlNamespaceManager nsmgr;
            XmlDocument xmlDoc = GetDocument(currentHierarchy, out nsmgr);

            XmlNode targetSection =  xmlDoc.SelectSingleNode(String.Format("/o:Notebooks/o:Notebook[@name='{0}']/o:Section[@name='{1}']", options.NotebookName, options.SectionName), nsmgr);
            string sectionId = targetSection.Attributes["ID"].Value;
            XmlNode currentPage = xmlDoc.SelectSingleNode(String.Format("/o:Notebooks/o:Notebook[@name='{0}']/o:Section[@name='{1}']/o:Page[@name='{2}']", options.NotebookName, options.SectionName, pageName), nsmgr);

            string pageId;
            if (currentPage != null)
            {
                pageId = currentPage.Attributes["ID"].Value;
            }
            else
            {
                pageId = CreateNewPage(pageName, sectionId);
            }

            return pageId;
        }

        private string CreateNewPage(string pageName, string sectionId)
        {
            string newPageId;
            app.CreateNewPage(sectionId, out newPageId, NewPageStyle.npsBlankPageWithTitle);
            string defaultPageContentFormat = @"<?xml version=""1.0""?>
<one:Page xmlns:one=""http://schemas.microsoft.com/office/onenote/2007/onenote"" ID=""{0}"" name=""{1}"">
    <one:Title>
        <one:OE>
            <one:T><![CDATA[{1}]]></one:T>
        </one:OE>
    </one:Title>
</one:Page>";

            string defaultContent = String.Format(defaultPageContentFormat, newPageId, TopicName.GetFormattedName(pageName));
            app.UpdatePageContent(defaultContent, DateTime.MinValue);
            return newPageId;
        }

        private static string ConvertContentToOneXml(string[] content, IDictionary<string, WikiPage> pages)
        {
            const string tableStart = @"<one:OE><one:Table bordersVisible=""true"">";
            const string tableEnd = @"</one:Table></one:OE>";
            StringBuilder output = new StringBuilder("<one:Outline><one:OEChildren>");
            bool inTable = false;
            foreach (string line in content)
            {
                if (line.StartsWith("@")) continue;
                string newLine = line;
                foreach (TopicName link in TopicParser.ParseTopicLinks(line))
                {
                    WikiPage targetPage = pages.ContainsKey(link.LocalName) ? pages[link.LocalName] : null;
                    if (targetPage != null)
                    {
                        string anchor = String.Format(@"<a href=""{0}"">{1}</a>", targetPage.Link, link.FormattedName);
                        newLine = newLine.Replace(link.LocalName, anchor);
                    }
                }
                newLine = replaceFormatting(newLine);

                string tableLine = replaceTables(newLine);
                if (tableLine != null)
                {
                    if (!inTable)
                    {
                        output.Append(tableStart);
                    }
                    output.Append(tableLine);
                    inTable = true;
                    continue;
                }
                else
                {
                    if (inTable)
                    {
                        output.Append(tableEnd);
                        inTable = false;
                    }
                }

                string bulletLine = replaceBullets(newLine);
                if (bulletLine != null)
                {
                    output.Append(bulletLine);
                    continue;
                }

                output.AppendFormat(@"<one:OE><one:T><![CDATA[{0}]]></one:T></one:OE>", newLine);
            }
            if (inTable)
            {
                output.Append(tableEnd);
            }
            output.Append("</one:OEChildren></one:Outline>");
            return output.ToString();
        }

        private static string replaceTables(string line)
        {
            Match found = Regex.Match(line, @"^\|\|(?<insideRow>.*)\|\|$");
            if (!found.Success) return null;
            string cellFormat = @"<one:Cell><one:OEChildren><one:OE><one:T><![CDATA[{0}]]></one:T></one:OE></one:OEChildren></one:Cell>";

            string innerTable = "|" + found.Groups["insideRow"].Value + "|";
            StringBuilder table = new StringBuilder("<one:Row>");
            foreach (Match match in Regex.Matches(innerTable, @"\|(?<cell>.*?)\|"))
            {
                table.AppendFormat(cellFormat, match.Groups["cell"].Value);
            }
            table.Append("</one:Row>");
            return table.ToString();
        }

        private static string replaceBullets(string line)
        {
            string bulletFormat;
            Match found = Regex.Match(line, @"(\t|\s{8})(?<type>\*|1\.)(?<restOfLine>.*)");
            if (!found.Success) return null;
            if (found.Groups["type"].Value == "*")
            {
                bulletFormat = @"<one:OE><one:List><one:Bullet bullet=""2""/></one:List><one:T><![CDATA[{0}]]></one:T></one:OE>";
            }
            else
            {
                bulletFormat = @"<one:OE><one:List><one:Number numberSequence=""0"" numberFormat=""##."" /></one:List><one:T><![CDATA[{0}]]></one:T></one:OE>";
            }
            return String.Format(bulletFormat, found.Groups["restOfLine"].Value);
        }

        private static string replaceFormatting(string line)
        {
            line = Regex.Replace(line, @"\*(?<word>.*?)\*", delegate(Match m) { return String.Format("<span style='font-weight:bold'>{0}</span>", m.Groups["word"].Value); });
            line = Regex.Replace(line, @"^!+(?<word>.*)$", delegate(Match m) { return String.Format("<span style='font-weight:bold'>{0}</span>", m.Groups["word"].Value); });
            line = Regex.Replace(line, @"'''(?<word>.*?)'''", delegate(Match m) { return String.Format("<span style='font-weight:bold'>{0}</span>", m.Groups["word"].Value); });
            line = Regex.Replace(line, @"''(?<word>.*?)''", delegate(Match m) { return String.Format("<span style='font-style:italic'>{0}</span>", m.Groups["word"].Value); });
            return line;
        }
    }
}


namespace Wiki2One
{
    public class WikiPage
    {
        private string[] content;
        private string link;
        private string id;

        public WikiPage(string id, string[] content, string link)
        {
            this.id = id;
            this.content = content;
            this.link = link;
        }


        public string Id
        {
            get { return id; }
        }

        public string[] Content
        {
            get { return content; }
        }

        public string Link
        {
            get { return link; }
        }
    }
}

﻿using StructureMap;
using StructureMap.Graph;

namespace Opinionated.Web
{
    public static class BootStrapper
    {
        public static void BootStrap()
        {
            StructureMapConfiguration.ScanAssemblies()
                .IncludeTheCallingAssembly()
                .With(new DefaultConventionScanner())
                .With(new ControllerConvention());
        }
    }
}

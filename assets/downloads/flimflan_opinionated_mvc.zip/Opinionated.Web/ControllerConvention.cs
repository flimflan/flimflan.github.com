using System;
using System.Web.Mvc;
using StructureMap.Configuration.DSL;
using StructureMap.Graph;
using StructureMap.Pipeline;

namespace Opinionated.Web
{
    public class ControllerConvention : TypeRules, ITypeScanner
    {
        #region ITypeScanner Members

        public void Process(Type type, Registry registry)
        {
            if (CanBeCast(typeof (IController), type))
            {
                string name = type.Name.Replace("Controller", "").ToLower();
                registry.AddInstanceOf(typeof (IController), new ConfiguredInstance(type).WithName(name));
            }
        }

        #endregion
    }
}
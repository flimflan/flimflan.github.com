﻿using System;
using System.ComponentModel;
using System.Reflection;
using System.Web.Mvc;
using System.Linq;

namespace Opinionated.Web.Controllers
{
    public class OpinionatedController : Controller
    {
        public OpinionatedController()
        {
            ActionInvoker = new OpionatedActionInvoker();
        }

        public class OpionatedActionInvoker : ControllerActionInvoker
        {
            protected override object GetParameterValue(ParameterInfo parameterInfo)
            {
                var parameterType = parameterInfo.ParameterType;

                if (parameterType.IsPrimitive)
                {
                    return getValueFromInput(parameterInfo.Name, parameterType);
                }

                var complexActionParameter = Activator.CreateInstance(parameterType);
                foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(complexActionParameter))
                {
                    object propertyValue = getValueFromInput(descriptor.Name, descriptor.PropertyType);
                    if (propertyValue != null)
                    {
                        descriptor.SetValue(complexActionParameter, propertyValue);
                    }
                }
                return complexActionParameter;
            }

            private object getValueFromInput(string parameterName, Type parameterType)
            {
                object propertyValue;
                ControllerContext.RouteData.Values.TryGetValue(parameterName, out propertyValue);
                if (propertyValue == null)
                {
                    propertyValue = ControllerContext.HttpContext.Request.Params[parameterName];
                }

                return TypeDescriptor.GetConverter(parameterType).ConvertFrom(propertyValue);
            }

            protected override ActionResult InvokeActionMethod(MethodInfo methodInfo, System.Collections.Generic.IDictionary<string, object> parameters)
            {
                object[] actionMethodParams = new object[0];
                if (methodInfo.GetParameters().Length > 0)
                {
                    actionMethodParams = new[] { parameters.Values.ElementAtOrDefault(0) };
                }

                var viewModel = methodInfo.Invoke(ControllerContext.Controller, actionMethodParams);

                var responseViewModel = viewModel as ResponseViewModel;
                if (responseViewModel != null && responseViewModel.OverrideResult != null)
                {
                    return responseViewModel.OverrideResult;
                }

                return new ViewResult { ViewData = new ViewDataDictionary { Model = viewModel } };
            }
        }
    }

    public class ResponseViewModel
    {
        public ActionResult OverrideResult { get; set; }
    }
}

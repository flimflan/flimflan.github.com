﻿using System.Web.Mvc;
using Opinionated.Web.Models;

namespace Opinionated.Web.Controllers
{
    public class SpeakerController : OpinionatedController
    {
        private readonly IConferenceRepository _conferenceRepository;
        private readonly IClock _clock;

        public SpeakerController(IConferenceRepository _conferenceRepository, IClock _clock)
        {
            this._conferenceRepository = _conferenceRepository;
            this._clock = _clock;
        }

        public SpeakerListViewModel List(SpeakerListRequest request)
        {
            Conference conference = _conferenceRepository.GetConferenceByKey(request.ConferenceKey);
            if (conference == null)
            {
                return new SpeakerListViewModel { OverrideResult = new RedirectResult("errorpage.aspx") };
            }

            var scheduledConference = new Schedule(conference);
            Speaker[] speakers = conference.GetSpeakers();

            int effectivePage = request.DisplayPage.GetValueOrDefault(0);
            int effectivePerPage = request.DisplayPageCount.GetValueOrDefault(20);
            return new SpeakerListViewModel
                       {
                           Conference = scheduledConference,
                           Speakers = speakers,
                           DisplayPage = effectivePage,
                           DisplayPageCount = effectivePerPage
                       };
        }
    }


    public class SpeakerListRequest
    {
        public string ConferenceKey { get; set; }

        public int? DisplayPage { get; set; }

        public int? DisplayPageCount { get; set; }
    }

    public class SpeakerListViewModel : ResponseViewModel
    {
        public Schedule Conference { get; set; }

        public Speaker[] Speakers { get; set; }

        public int DisplayPage { get; set; }

        public int DisplayPageCount { get; set; }
    }
}

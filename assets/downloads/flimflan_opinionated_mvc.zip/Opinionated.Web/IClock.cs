namespace Opinionated.Web
{
    public interface IClock
    {
    }

    public class Clock : IClock
    {
    }
}
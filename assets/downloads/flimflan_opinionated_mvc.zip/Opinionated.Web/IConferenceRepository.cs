using Opinionated.Web.Models;

namespace Opinionated.Web
{
    public interface IConferenceRepository
    {
        Conference GetConferenceByKey(string key);
    }

    public class ConferenceRepository : IConferenceRepository
    {
        public Conference GetConferenceByKey(string key)
        {
            var conference = new Conference(key, key + " Camp");
            return conference;
        }
    }
}
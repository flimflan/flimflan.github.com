using System.Collections.Generic;
using Opinionated.Web.Models;

namespace Opinionated.Web.Models
{
    public class Conference
    {
        private readonly List<Speaker> _speakers = new List<Speaker>();
        public string Key { get; set; }
        public string Name { get; set; }

        public Conference(string key, string name)
        {
            Key = key;
            Name = name;
        }

        public Speaker[] GetSpeakers()
        {
            return _speakers.ToArray();
        }

        public void AddSpeaker(Person person, string name, string biography, string imagePath)
        {
            _speakers.Add(new Speaker(person, name, biography, imagePath));
        }
    }
}
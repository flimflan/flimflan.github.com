using Opinionated.Web.Models;

namespace Opinionated.Web.Models
{
    public class Schedule
    {
        private readonly Conference conference;

        public Schedule(Conference conference)
        {
            this.conference = conference;
        }

        public string ConferenceName { get { return conference.Name; } }
        }
}
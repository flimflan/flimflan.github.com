using Opinionated.Web.Models;

namespace Opinionated.Web.Models
{
    public class Speaker
    {
        private readonly string speakerKey;
        private readonly string bio;

        public Speaker(Person person, string speakerKey, string bio, string avatarUrl)
        {
            this.speakerKey = speakerKey;
            this.bio = bio;
        }

        public override string ToString()
        {
            return string.Format("SpeakerKey: {0}, Bio: {1}", speakerKey, bio);
        }
    }
}
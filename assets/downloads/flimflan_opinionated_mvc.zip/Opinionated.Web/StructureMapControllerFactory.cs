using System.Web.Mvc;
using System.Web.Routing;
using StructureMap;

namespace Opinionated.Web
{
    public class StructureMapControllerFactory : DefaultControllerFactory
    {
        public override IController CreateController(RequestContext context, string controllerName)
        {
            return ObjectFactory.GetNamedInstance<IController>(controllerName.ToLowerInvariant());
        }
    }
}
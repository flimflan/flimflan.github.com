﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Opinionated.Web.Controllers;

namespace Opinionated.Web.Views.Speaker
{
    public partial class List : ViewPage<SpeakerListViewModel>
    {
    }
}

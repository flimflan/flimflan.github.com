﻿using System;
using NUnit.Framework;
using Rhino.Mocks;
using Rhino.Mocks.Interfaces;
using StructureMap.AutoMocking;
using StructureMap.Util;

namespace Tests
{
    public class ControllerActionTest<CONTROLLER, INPUT, OUTPUT> 
        where CONTROLLER : class 
        where OUTPUT : class
    {
        private readonly Func<CONTROLLER, INPUT, OUTPUT> _action;
        private OUTPUT _output;
        private RhinoAutoMocker<CONTROLLER> _autoMocker;
        private Cache<Type, object> _stubs;

        protected ControllerActionTest(Func<CONTROLLER, INPUT, OUTPUT> action)
        {
            this._action = action;
        }

        [SetUp]
        public void Setup()
        {
            _autoMocker = new RhinoAutoMocker<CONTROLLER>();
            _stubs = new Cache<Type, object>(type =>
            {
                object stub = _autoMocker.Stub(type);
                _autoMocker.Inject(type, stub);

                return stub;
            });

            underTheseConditions();
        }

        public INPUT Input { get; set; }
        public OUTPUT Output
        {
            get
            {
                if (_output == null)
                {
                    _output = getOutput();
                }
                return _output;
            }
        }

        private OUTPUT getOutput()
        {
            _autoMocker.ReplayAll();
            return _action(_autoMocker.ClassUnderTest, Input);
        }

        protected virtual void underTheseConditions()
        {
            
        }

        public IMethodOptions<R> GivenThat<T, R>(Func<T, R> func)
        {
            T stub = (T)_stubs.Retrieve(typeof(T));
            return stub.Stub(func);
        }

    }
}

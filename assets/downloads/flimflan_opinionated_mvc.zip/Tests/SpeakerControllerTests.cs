﻿using System.Web.Mvc;
using NUnit.Framework;
using Opinionated.Web;
using Opinionated.Web.Controllers;
using Opinionated.Web.Models;

namespace Tests
{
    [TestFixture]
    public class When_listing_the_speakers : ControllerActionTest<SpeakerController, SpeakerListRequest, SpeakerListViewModel>
    {
        public When_listing_the_speakers() : base((c, input) => c.List(input)) { }

        protected override void underTheseConditions()
        {
            var knownConferenceKey = "austincodecamp2008";
            Conference conference = new Conference(knownConferenceKey, "Austin Code Camp");
            var p = new Person("joe", "dimaggio", "jd@baseball.com");
            var p2 = new Person("marilyn", "monroe", "m@m.com");
            conference.AddSpeaker(p, "joedimaggio", "bio here...", "avatar.jpg");
            conference.AddSpeaker(p2, "marilynmonroe", "bio here...", "avatar.jpg");

            Input = new SpeakerListRequest { ConferenceKey = knownConferenceKey };
            GivenThat<IConferenceRepository, Conference>(r => r.GetConferenceByKey(knownConferenceKey)).Return(conference);
        }

        [Test]
        public void Should_display_the_default_view()
        {
            Output.OverrideResult.ShouldBeNull();
        }

        [Test]
        public void Should_provide_the_speakers_related_to_the_conference()
        {
            Output.Speakers.ShouldNotBeNull();
            Output.Speakers.Length.ShouldEqual(2);
        }

    }
}

using System;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

public class SafeWaitCallback
{
    public static Uri ApplicationUri;

    System.Threading.WaitCallback callback;

    public System.Threading.WaitCallback Call(System.Threading.WaitCallback callback)
    {
        this.callback = callback;
        return CallbackWrapper;
    }

    private void CallbackWrapper(object state)
    {
        try
        {
            callback(state);
        }
        catch (Exception e)
        {
            byte[] exceptionData;

            MemoryStream stream = new MemoryStream();
            BinaryFormatter formatter = new BinaryFormatter(null, new StreamingContext(StreamingContextStates.Persistence));
            formatter.Serialize(stream, e);
            exceptionData = stream.ToArray();

            WebClient client = new WebClient();
            Uri handler = new Uri(ApplicationUri, "TransferException.axd");
            try
            {
                client.UploadData(handler, exceptionData);
            }
            catch (WebException) { }
        }
    }
}

using System;
using System.Web;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

public class TransferredExceptionHandler : IHttpHandler
{
    public bool IsReusable { get { return true; }
    }

    public void ProcessRequest(HttpContext context)
    {
        byte[] exceptionData = new byte[context.Request.ContentLength];
        context.Request.InputStream.Read(exceptionData, 0, exceptionData.Length);

        Exception transferredException;
        MemoryStream stream = new MemoryStream(exceptionData);
        BinaryFormatter formatter = new BinaryFormatter(null, new StreamingContext(StreamingContextStates.Persistence));
        transferredException = (Exception)formatter.Deserialize(stream);
        throw new Exception("[Background exception transferred - see InnerException]", transferredException);
    }
}
